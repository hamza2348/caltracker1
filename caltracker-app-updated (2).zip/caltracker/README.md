# CalTracker AI — complete, fully local Flutter app (web-compatible)

No backend. No MongoDB. No login. Everything lives on-device via `shared_preferences`
(JSON-encoded locally) — which works identically on **Android, iOS, Windows, macOS, Linux,
and Web** with zero extra native setup. This is the complete app — profile, AI photo
scanning, barcode scanning, fully offline manual entry, favorites, progress tracking, and history.

## Run it

```
cd flutter_app
flutter pub get
flutter run -d chrome     # for web
flutter run                # or pick any connected device
```

No server to start, no `.env`, no database to provision, no wasm files, no service worker
setup. That's the whole thing.

## Why shared_preferences instead of SQLite
The earlier version used `sqflite`, which doesn't run on web without extra native
plumbing (a `sqlite3.wasm` file, a service worker, etc). Since you wanted this running
in the browser without backend complexity, storage was switched to `shared_preferences`
— each "table" (profile, logs, weight history, activity, favorites) is stored as a
JSON-encoded list under one preference key (see `core/db/local_store.dart`). Same data,
same features, just a storage engine that works everywhere without setup.


## The "no login" flow
1. First launch → 5-step Create Profile wizard (name, DOB, height, weight, goal/activity).
2. Calorie/macro targets are calculated locally (`core/calc/goal_calculator.dart`, Mifflin-St Jeor formula) and saved to the local `profile` table.
3. Every future launch reads that table — if a row exists, the app skips straight to Home.
4. "Reset profile" (Profile tab) wipes every local table and is the only way back to Create Profile.

## Four ways to log food (tap the floating scan button, or the Home quick-add row)

| Method | How it works | Needs internet? |
|---|---|---|
| **AI photo scan** | Photo → Claude vision API identifies items + estimates portions → cross-checked against Open Food Facts for real nutrition data where a match exists → you confirm/adjust before logging | Yes |
| **Barcode scan** | `mobile_scanner` reads the barcode → looked up on Open Food Facts (free, no key) → adjust serving size → log | Yes |
| **Manual entry (search)** | Search a bundled list of ~40 common foods (`assets/common_foods.json`) → adjust portion → log | **No — fully offline** |
| **Manual entry (custom)** | Type your own food name + calories/macros directly | **No — fully offline** |
| **Favorites** | One-tap re-log of anything you've saved as a favorite from Manual Entry | **No — fully offline** |

This means the app is usable in airplane mode via manual entry + favorites — only the AI/barcode paths need a connection.

## AI scanning setup
Profile tab → Settings & API key → paste an Anthropic API key (console.anthropic.com) → Save.
Stored only in local device preferences — there's no server to hold it instead.

> Trade-off worth knowing: embedding a personal API key in the app like this is fine for your own
> device, but isn't how you'd distribute this publicly (the key is extractable from the installed
> app). For a public release, reintroduce a thin backend just to proxy that one call.

## Project structure
```
flutter_app/
├── assets/common_foods.json           # offline food database for manual entry
├── lib/
│   ├── core/
│   │   ├── calc/goal_calculator.dart  # BMR/TDEE + macro math, pure Dart
│   │   ├── db/local_store.dart        # shared_preferences storage: profile, logs,
│   │   │                              #   weight_logs, activity_logs, favorite_foods
│   │   └── theme/app_theme.dart       # cream/black aesthetic
│   ├── models/                        # UserProfile, ScannedFoodItem
│   ├── services/
│   │   ├── logs_service.dart          # meal logs CRUD + daily totals + history grouping
│   │   ├── weight_service.dart        # weight history
│   │   ├── activity_service.dart      # steps/workouts (Progress tab)
│   │   ├── favorites_service.dart     # saved foods for one-tap re-logging
│   │   ├── local_food_database_service.dart  # offline search over common_foods.json
│   │   ├── vision_scan_service.dart   # calls Claude vision API directly
│   │   ├── open_food_facts_service.dart      # barcode + name lookups
│   │   └── settings_service.dart      # stores the Anthropic API key locally
│   ├── providers/profile_provider.dart # Riverpod state, reads/writes SQLite
│   └── screens/
│       ├── splash/                    # brief loading state while checking for a saved profile
│       ├── onboarding/                # 5-step Create Profile wizard
│       ├── root/                      # bottom nav shell + expandable scan FAB
│       ├── dashboard/                 # Home: calories left, macros, today's meals, quick-add row
│       ├── scan/                      # AI photo scanner
│       ├── barcode/                   # barcode scanner
│       ├── manual_entry/              # offline search + custom entry, with save-to-favorites
│       ├── favorites/                 # saved foods list, one-tap re-log
│       ├── progress/                  # steps, workouts, weight trend chart
│       ├── history/                   # 61-day summary + daily breakdown
│       ├── profile/                   # stats, Reset profile, link to Settings
│       └── settings/                  # Anthropic API key entry
```

## Known trade-offs of a fully local app
- **No multi-device sync** — data lives on one browser/device; clearing site data or uninstalling deletes everything.
- **No server-side key protection** for the Anthropic API key (see above) — doubly true on web, since browser storage is even easier to inspect than a mobile app's.
- **Web + AI/barcode scanning: possible CORS issues.** Calling `api.anthropic.com` and Open Food Facts directly from a browser tab depends on those services allowing cross-origin requests. If AI scan or barcode scan throw a network/CORS error on web specifically (but work fine on Android/Windows), that's why — browsers block cross-origin calls that don't return the right CORS headers, and this can't be fixed from the app code alone. If you hit this, Manual Entry and Favorites will still work perfectly on web since they never leave the device.
- **AI scan and barcode scan need internet** regardless of platform — vision AI can't run on-device, and Open Food Facts is a remote lookup. Manual entry and Favorites are the fully-offline paths.
- The bundled `common_foods.json` list is small (~40 items) by design — easy to extend by adding
  more entries in the same `{name, caloriesPer100g, proteinPer100g, carbsPer100g, fatPer100g}` shape.

## Possible next steps
- Expand `common_foods.json` with more items, or let users add their own entries into it permanently (currently favorites cover this).
- Add editing/deleting individual logged meals from the Home or History screens.
- Add a pedometer package to auto-track steps instead of manual entry.
- Swap the on-device Anthropic key for a small serverless proxy before any public release.
