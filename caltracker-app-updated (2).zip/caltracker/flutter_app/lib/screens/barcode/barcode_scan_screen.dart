import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_theme.dart';
import '../../services/open_food_facts_service.dart';
import '../../services/logs_service.dart';

class BarcodeScanScreen extends StatefulWidget {
  const BarcodeScanScreen({super.key});
  @override
  State<BarcodeScanScreen> createState() => _BarcodeScanScreenState();
}

class _BarcodeScanScreenState extends State<BarcodeScanScreen> {
  bool _looking = false;
  Map<String, dynamic>? _product;
  String? _error;
  double _grams = 100;
  String _mealType = 'lunch';
  final _controller = MobileScannerController();

  Future<void> _onDetect(BarcodeCapture capture) async {
    if (_looking || _product != null) return;
    final code = capture.barcodes.firstOrNull?.rawValue;
    if (code == null) return;

    setState(() => _looking = true);
    final product = await OpenFoodFactsService.lookupBarcode(code);
    setState(() {
      _looking = false;
      if (product == null) {
        _error = 'No product found for that barcode. Try manual entry instead.';
      } else {
        _product = product;
      }
    });
  }

  Future<void> _addToLog() async {
    if (_product == null) return;
    final factor = _grams / 100;
    await LogsService.addLog(
      name: _product!['name'],
      quantityGrams: _grams,
      calories: (_product!['caloriesPer100g'] * factor).round(),
      protein: (_product!['proteinPer100g'] * factor).round(),
      carbs: (_product!['carbsPer100g'] * factor).round(),
      fat: (_product!['fatPer100g'] * factor).round(),
      mealType: _mealType,
      date: DateFormat('yyyy-MM-dd').format(DateTime.now()),
    );
    if (mounted) Navigator.of(context).pop(true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Scan Barcode'),
      ),
      body: _product == null
          ? Stack(children: [
              MobileScanner(controller: _controller, onDetect: _onDetect),
              Center(
                child: Container(
                  width: 260, height: 160,
                  decoration: BoxDecoration(border: Border.all(color: Colors.white, width: 2), borderRadius: BorderRadius.circular(16)),
                ),
              ),
              if (_looking) const Positioned(bottom: 40, left: 0, right: 0, child: Center(child: CircularProgressIndicator(color: Colors.white))),
              if (_error != null)
                Positioned(
                  bottom: 40, left: 20, right: 20,
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: Colors.black87, borderRadius: BorderRadius.circular(12)),
                    child: Text(_error!, style: const TextStyle(color: Colors.white), textAlign: TextAlign.center),
                  ),
                ),
            ])
          : SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_product!['name'], style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                    if (_product!['brand'] != null) Text(_product!['brand'], style: const TextStyle(color: AppColors.textMuted)),
                    const SizedBox(height: 20),
                    Text('Serving size: ${_grams.round()}g', style: const TextStyle(fontWeight: FontWeight.w600)),
                    Slider(value: _grams, min: 10, max: 500, activeColor: AppColors.accent, onChanged: (v) => setState(() => _grams = v)),
                    const SizedBox(height: 12),
                    _NutrientRow(label: 'Calories', value: '${(_product!['caloriesPer100g'] * _grams / 100).round()} kcal'),
                    _NutrientRow(label: 'Protein', value: '${(_product!['proteinPer100g'] * _grams / 100).round()}g'),
                    _NutrientRow(label: 'Carbs', value: '${(_product!['carbsPer100g'] * _grams / 100).round()}g'),
                    _NutrientRow(label: 'Fat', value: '${(_product!['fatPer100g'] * _grams / 100).round()}g'),
                    const SizedBox(height: 16),
                    Wrap(spacing: 8, children: ['breakfast', 'lunch', 'dinner', 'snack'].map((m) {
                      final isSelected = _mealType == m;
                      return ChoiceChip(
                        label: Text(m[0].toUpperCase() + m.substring(1)),
                        selected: isSelected,
                        onSelected: (_) => setState(() => _mealType = m),
                        selectedColor: AppColors.accent,
                        labelStyle: TextStyle(color: isSelected ? Colors.white : AppColors.text),
                      );
                    }).toList()),
                    const Spacer(),
                    SizedBox(width: double.infinity, child: ElevatedButton(onPressed: _addToLog, child: const Text('Add to log'))),
                  ],
                ),
              ),
            ),
    );
  }
}

class _NutrientRow extends StatelessWidget {
  final String label, value;
  const _NutrientRow({required this.label, required this.value});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(label, style: const TextStyle(color: AppColors.textMuted)),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w700)),
      ]),
    );
  }
}
