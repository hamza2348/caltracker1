import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_theme.dart';
import '../../services/local_food_database_service.dart';
import '../../services/logs_service.dart';
import '../../services/favorites_service.dart';

/// Fully offline: search the bundled common-foods list, or type your own
/// custom entry if it's not in the list. No network call anywhere in here.
/// `prefill` lets Favorites jump straight to the portion editor for a saved food.
class ManualEntryScreen extends StatefulWidget {
  final Map<String, dynamic>? prefill;
  const ManualEntryScreen({super.key, this.prefill});
  @override
  State<ManualEntryScreen> createState() => _ManualEntryScreenState();
}

class _ManualEntryScreenState extends State<ManualEntryScreen> {
  final _searchController = TextEditingController();
  List<Map<String, dynamic>> _results = [];
  Map<String, dynamic>? _selected;
  double _grams = 100;
  String _mealType = 'lunch';
  bool _customMode = false;
  bool _savedFavorite = false;

  final _customNameController = TextEditingController();
  final _customCaloriesController = TextEditingController();
  final _customProteinController = TextEditingController();
  final _customCarbsController = TextEditingController();
  final _customFatController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.prefill != null) {
      _selected = widget.prefill;
    } else {
      _search('');
    }
  }

  Future<void> _search(String query) async {
    final results = await LocalFoodDatabaseService.search(query);
    setState(() => _results = results);
  }

  Future<void> _addToLog() async {
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());

    if (_customMode) {
      final calories = int.tryParse(_customCaloriesController.text) ?? 0;
      if (_customNameController.text.trim().isEmpty || calories == 0) return;
      await LogsService.addLog(
        name: _customNameController.text.trim(),
        quantityGrams: _grams,
        calories: calories,
        protein: int.tryParse(_customProteinController.text) ?? 0,
        carbs: int.tryParse(_customCarbsController.text) ?? 0,
        fat: int.tryParse(_customFatController.text) ?? 0,
        mealType: _mealType,
        date: today,
      );
    } else if (_selected != null) {
      final factor = _grams / 100;
      await LogsService.addLog(
        name: _selected!['name'],
        quantityGrams: _grams,
        calories: (_selected!['caloriesPer100g'] * factor).round(),
        protein: (_selected!['proteinPer100g'] * factor).round(),
        carbs: (_selected!['carbsPer100g'] * factor).round(),
        fat: (_selected!['fatPer100g'] * factor).round(),
        mealType: _mealType,
        date: today,
      );
    } else {
      return;
    }

    if (mounted) Navigator.of(context).pop(true);
  }

  Future<void> _saveFavorite() async {
    if (_customMode) {
      final calories = double.tryParse(_customCaloriesController.text) ?? 0;
      if (_customNameController.text.trim().isEmpty || calories == 0) return;
      // Custom entries are logged at a specific amount, not necessarily 100g,
      // so normalize to a per-100g rate before saving as a reusable favorite.
      final factor = 100 / _grams;
      await FavoritesService.save(
        name: _customNameController.text.trim(),
        caloriesPer100g: calories * factor,
        proteinPer100g: (double.tryParse(_customProteinController.text) ?? 0) * factor,
        carbsPer100g: (double.tryParse(_customCarbsController.text) ?? 0) * factor,
        fatPer100g: (double.tryParse(_customFatController.text) ?? 0) * factor,
      );
    } else if (_selected != null) {
      await FavoritesService.save(
        name: _selected!['name'],
        caloriesPer100g: (_selected!['caloriesPer100g'] as num).toDouble(),
        proteinPer100g: (_selected!['proteinPer100g'] as num).toDouble(),
        carbsPer100g: (_selected!['carbsPer100g'] as num).toDouble(),
        fatPer100g: (_selected!['fatPer100g'] as num).toDouble(),
      );
    } else {
      return;
    }
    setState(() => _savedFavorite = true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Manual Entry'),
        actions: [
          TextButton(
            onPressed: () => setState(() {
              _customMode = !_customMode;
              _selected = null;
            }),
            child: Text(_customMode ? 'Search instead' : 'Custom food'),
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: _customMode ? _buildCustomForm() : _buildSearchForm(),
        ),
      ),
    );
  }

  Widget _buildSearchForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextField(
          controller: _searchController,
          onChanged: _search,
          decoration: const InputDecoration(hintText: 'Search foods (e.g. chicken, rice, apple)', prefixIcon: Icon(Icons.search)),
        ),
        const SizedBox(height: 12),
        const Text('Works fully offline — searches a built-in food list', style: TextStyle(fontSize: 12, color: AppColors.textMuted)),
        const SizedBox(height: 12),
        Expanded(
          child: _selected == null
              ? ListView.builder(
                  itemCount: _results.length,
                  itemBuilder: (context, i) {
                    final food = _results[i];
                    return ListTile(
                      title: Text(food['name']),
                      subtitle: Text('${food['caloriesPer100g']} kcal / 100g'),
                      onTap: () => setState(() => _selected = food),
                    );
                  },
                )
              : _buildPortionEditor(),
        ),
      ],
    );
  }

  Widget _buildPortionEditor() {
    final factor = _grams / 100;
    final food = _selected!;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          Expanded(child: Text(food['name'], style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
          TextButton(onPressed: () => setState(() => _selected = null), child: const Text('Change')),
        ]),
        const SizedBox(height: 16),
        Text('${_grams.round()}g', style: const TextStyle(fontWeight: FontWeight.w600)),
        Slider(value: _grams, min: 5, max: 800, activeColor: AppColors.accent, onChanged: (v) => setState(() => _grams = v)),
        const SizedBox(height: 8),
        _NutrientRow(label: 'Calories', value: '${(food['caloriesPer100g'] * factor).round()} kcal'),
        _NutrientRow(label: 'Protein', value: '${(food['proteinPer100g'] * factor).round()}g'),
        _NutrientRow(label: 'Carbs', value: '${(food['carbsPer100g'] * factor).round()}g'),
        _NutrientRow(label: 'Fat', value: '${(food['fatPer100g'] * factor).round()}g'),
        const SizedBox(height: 16),
        _mealTypeChips(),
        const SizedBox(height: 10),
        TextButton.icon(
          onPressed: _savedFavorite ? null : _saveFavorite,
          icon: Icon(_savedFavorite ? Icons.favorite : Icons.favorite_border, color: AppColors.red),
          label: Text(_savedFavorite ? 'Saved to favorites' : 'Save as favorite'),
        ),
        const Spacer(),
        SizedBox(width: double.infinity, child: ElevatedButton(onPressed: _addToLog, child: const Text('Add to log'))),
      ],
    );
  }

  Widget _buildCustomForm() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Custom food entry', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
          const SizedBox(height: 4),
          const Text('For anything not in the food list', style: TextStyle(fontSize: 12, color: AppColors.textMuted)),
          const SizedBox(height: 16),
          TextField(controller: _customNameController, decoration: const InputDecoration(labelText: 'Food name')),
          const SizedBox(height: 12),
          TextField(controller: _customCaloriesController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Calories (kcal)')),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: TextField(controller: _customProteinController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Protein (g)'))),
            const SizedBox(width: 10),
            Expanded(child: TextField(controller: _customCarbsController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Carbs (g)'))),
            const SizedBox(width: 10),
            Expanded(child: TextField(controller: _customFatController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Fat (g)'))),
          ]),
          const SizedBox(height: 16),
          _mealTypeChips(),
          const SizedBox(height: 10),
          TextButton.icon(
            onPressed: _savedFavorite ? null : _saveFavorite,
            icon: Icon(_savedFavorite ? Icons.favorite : Icons.favorite_border, color: AppColors.red),
            label: Text(_savedFavorite ? 'Saved to favorites' : 'Save as favorite'),
          ),
          const SizedBox(height: 10),
          SizedBox(width: double.infinity, child: ElevatedButton(onPressed: _addToLog, child: const Text('Add to log'))),
        ],
      ),
    );
  }

  Widget _mealTypeChips() {
    return Wrap(spacing: 8, children: ['breakfast', 'lunch', 'dinner', 'snack'].map((m) {
      final isSelected = _mealType == m;
      return ChoiceChip(
        label: Text(m[0].toUpperCase() + m.substring(1)),
        selected: isSelected,
        onSelected: (_) => setState(() => _mealType = m),
        selectedColor: AppColors.accent,
        labelStyle: TextStyle(color: isSelected ? Colors.white : AppColors.text),
      );
    }).toList());
  }
}

class _NutrientRow extends StatelessWidget {
  final String label, value;
  const _NutrientRow({required this.label, required this.value});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(label, style: const TextStyle(color: AppColors.textMuted)),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w700)),
      ]),
    );
  }
}
