import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/profile_provider.dart';
import '../../services/activity_service.dart';
import '../../services/weight_service.dart';
import '../../services/logs_service.dart';
import '../../services/step_counter_service.dart';

class ProgressScreen extends ConsumerStatefulWidget {
  const ProgressScreen({super.key});
  @override
  ConsumerState<ProgressScreen> createState() => _ProgressScreenState();
}

class _ProgressScreenState extends ConsumerState<ProgressScreen> {
  Map<String, dynamic>? _activity;
  Map<String, dynamic>? _calorieTotals;
  List<Map<String, dynamic>> _weightHistory = [];
  bool _loading = true;

  final _stepper = StepCounterService.instance;
  StreamSubscription<int>? _stepsSub;
  StreamSubscription<String>? _statusSub;
  StreamSubscription<StepTrackingState>? _stateSub;

  int _liveSteps = 0;
  bool _isWalking = false;
  StepTrackingState _trackingState = StepTrackingState.unknown;

  @override
  void initState() {
    super.initState();
    _load();
    _startLiveSteps();
  }

  void _startLiveSteps() {
    _stateSub = _stepper.state.listen((s) => setState(() => _trackingState = s));
    _stepsSub = _stepper.steps.listen((s) {
      setState(() => _liveSteps = s);
      ActivityService.syncLiveSteps(s); // fully automatic — no manual entry anywhere
    });
    _statusSub = _stepper.walkingStatus.listen((status) {
      setState(() => _isWalking = status == 'walking');
    });
    _stepper.start();
  }

  @override
  void dispose() {
    _stepsSub?.cancel();
    _statusSub?.cancel();
    _stateSub?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final activity = await ActivityService.todayEntry();
    final calorieTotals = await LogsService.totalsForDate(today);
    final weights = await WeightService.history();
    setState(() {
      _activity = activity;
      _calorieTotals = calorieTotals;
      _weightHistory = weights;
      _loading = false;
    });
  }

  Future<void> _logWorkout() async {
    final controller = TextEditingController();
    final calories = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Log workout'),
        content: TextField(controller: controller, keyboardType: TextInputType.number, autofocus: true, decoration: const InputDecoration(hintText: 'Calories burned')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, int.tryParse(controller.text)), child: const Text('Save')),
        ],
      ),
    );
    if (calories != null) {
      await ActivityService.logWorkout(calories);
      _load();
    }
  }

  Future<void> _logWeight() async {
    final controller = TextEditingController();
    final weight = await showDialog<double>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Log weight'),
        content: TextField(controller: controller, keyboardType: const TextInputType.numberWithOptions(decimal: true), autofocus: true, decoration: const InputDecoration(suffixText: 'kg')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, double.tryParse(controller.text)), child: const Text('Save')),
        ],
      ),
    );
    if (weight != null) {
      await WeightService.addEntry(weight);
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final steps = _liveSteps;
    final workouts = _activity?['workoutsCount'] ?? 0;
    final caloriesBurned = _activity?['caloriesBurned'] ?? 0;
    const stepGoal = 10000;

    final profile = ref.watch(profileProvider).profile;
    final calorieGoal = profile?.dailyCalorieGoal ?? 2000;
    final calorieConsumed = (_calorieTotals?['calories'] ?? 0) as int;
    final calorieProgress = calorieGoal == 0 ? 0.0 : (calorieConsumed / calorieGoal).clamp(0, 1).toDouble();
    final stepProgress = (steps / stepGoal).clamp(0, 1).toDouble();
    final overallProgress = ((calorieProgress + stepProgress) / 2).clamp(0, 1).toDouble();

    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _load,
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Text('Progress', style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 16),
              _FadeSlideIn(
                delay: 0,
                child: _OverallProgressCard(
                  overallProgress: overallProgress,
                  calorieProgress: calorieProgress,
                  stepProgress: stepProgress,
                ),
              ),
              const SizedBox(height: 20),
              Text("Today's activity", style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 10),
              _FadeSlideIn(
                delay: 40,
                child: _ActivityCard(
                  icon: Icons.local_fire_department_rounded,
                  title: 'Calories burned',
                  subtitle: '$workouts workouts',
                  value: '$caloriesBurned kcal',
                ),
              ),
              const SizedBox(height: 10),
              _FadeSlideIn(
                delay: 80,
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(16)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(children: [
                        const Icon(Icons.directions_walk_rounded, color: AppColors.textMuted),
                        const SizedBox(width: 10),
                        const Expanded(child: Text('Steps', style: TextStyle(fontWeight: FontWeight.w600))),
                        _LiveDot(active: _trackingState == StepTrackingState.live),
                        const SizedBox(width: 6),
                        _AnimatedStepCount(steps: steps),
                      ]),
                      const SizedBox(height: 10),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: TweenAnimationBuilder<double>(
                          duration: const Duration(milliseconds: 500),
                          curve: Curves.easeOutCubic,
                          tween: Tween(begin: 0, end: (steps / stepGoal).clamp(0, 1).toDouble()),
                          builder: (context, value, _) => LinearProgressIndicator(
                            value: value,
                            minHeight: 8,
                            backgroundColor: AppColors.border,
                            valueColor: const AlwaysStoppedAnimation(AppColors.accent),
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(_statusLine(steps, stepGoal), style: const TextStyle(fontSize: 11, color: AppColors.textMuted)),
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 250),
                        child: _isWalking
                            ? const Padding(padding: EdgeInsets.only(top: 8), key: ValueKey('walking'), child: _WalkingBadge())
                            : const SizedBox(key: ValueKey('idle'), height: 0),
                      ),
                      if (_trackingState == StepTrackingState.unsupported)
                        const Padding(
                          padding: EdgeInsets.only(top: 8),
                          child: Text(
                            "No motion sensor detected on this device/browser, so steps can't be counted here — try on a phone.",
                            style: TextStyle(fontSize: 11, color: AppColors.textMuted),
                          ),
                        ),
                      if (_trackingState == StepTrackingState.permissionDenied)
                        Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: Row(children: [
                            const Expanded(child: Text("Motion & fitness permission is off, so steps can't be counted.", style: TextStyle(fontSize: 11, color: AppColors.red))),
                            TextButton(
                              onPressed: () => _stepper.openSystemSettings(),
                              style: TextButton.styleFrom(padding: EdgeInsets.zero, minimumSize: const Size(0, 0)),
                              child: const Text('Enable', style: TextStyle(fontSize: 11)),
                            ),
                          ]),
                        ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: _logWorkout, icon: const Icon(Icons.add), label: const Text('Log a workout'))),
              const SizedBox(height: 24),
              Text('Body metrics', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 10),
              _FadeSlideIn(
                delay: 160,
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(16)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(children: [
                        const Icon(Icons.monitor_weight_outlined, color: AppColors.textMuted),
                        const SizedBox(width: 10),
                        const Expanded(child: Text('Weight', style: TextStyle(fontWeight: FontWeight.w600))),
                        Text(_weightHistory.isNotEmpty ? '${_weightHistory.last['weightKg']} kg' : '-', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                        IconButton(onPressed: _logWeight, icon: const Icon(Icons.add_circle_outline)),
                      ]),
                      if (_weightHistory.length >= 2)
                        SizedBox(
                          height: 120,
                          child: LineChart(LineChartData(
                            gridData: const FlGridData(show: false),
                            titlesData: const FlTitlesData(show: false),
                            borderData: FlBorderData(show: false),
                            lineBarsData: [
                              LineChartBarData(
                                spots: _weightHistory.asMap().entries.map((e) => FlSpot(e.key.toDouble(), (e.value['weightKg'] as num).toDouble())).toList(),
                                isCurved: true,
                                color: AppColors.accent,
                                barWidth: 2,
                                dotData: const FlDotData(show: false),
                              ),
                            ],
                          )),
                        ),
                      if (_weightHistory.isEmpty)
                        const Padding(padding: EdgeInsets.only(top: 12), child: Text('No weight entries yet — tap + to log your first one.', style: TextStyle(color: AppColors.textMuted))),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _statusLine(int steps, int goal) {
    final pct = ((steps / goal) * 100).round();
    return '$pct% of goal · Goal: $goal';
  }
}

/// Animates the step count ticking upward instead of jumping, so live
/// updates feel alive rather than snapping.
class _AnimatedStepCount extends StatelessWidget {
  final int steps;
  const _AnimatedStepCount({required this.steps});
  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<int>(
      duration: const Duration(milliseconds: 400),
      curve: Curves.easeOut,
      tween: IntTween(begin: 0, end: steps),
      builder: (context, value, _) => Text('$value', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
    );
  }
}

/// Simple fade + slide-up entrance used to stagger cards in on load.
class _FadeSlideIn extends StatefulWidget {
  final Widget child;
  final int delay;
  const _FadeSlideIn({required this.child, this.delay = 0});
  @override
  State<_FadeSlideIn> createState() => _FadeSlideInState();
}

class _FadeSlideInState extends State<_FadeSlideIn> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 420));

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: widget.delay), () {
      if (mounted) _controller.forward();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final curved = CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic);
    return FadeTransition(
      opacity: curved,
      child: SlideTransition(
        position: Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero).animate(curved),
        child: widget.child,
      ),
    );
  }
}

class _OverallProgressCard extends StatelessWidget {
  final double overallProgress, calorieProgress, stepProgress;
  const _OverallProgressCard({required this.overallProgress, required this.calorieProgress, required this.stepProgress});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(20)),
      child: Row(
        children: [
          SizedBox(
            width: 84,
            height: 84,
            child: Stack(alignment: Alignment.center, children: [
              TweenAnimationBuilder<double>(
                duration: const Duration(milliseconds: 700),
                curve: Curves.easeOutCubic,
                tween: Tween(begin: 0, end: overallProgress),
                builder: (context, value, _) => CircularProgressIndicator(
                  value: value,
                  strokeWidth: 7,
                  backgroundColor: AppColors.border,
                  valueColor: const AlwaysStoppedAnimation(AppColors.accent),
                ),
              ),
              TweenAnimationBuilder<double>(
                duration: const Duration(milliseconds: 700),
                curve: Curves.easeOutCubic,
                tween: Tween(begin: 0, end: overallProgress * 100),
                builder: (context, value, _) => Text('${value.round()}%', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              ),
            ]),
          ),
          const SizedBox(width: 18),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Today's goal progress", style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                const SizedBox(height: 12),
                _MiniProgressRow(label: 'Calories', progress: calorieProgress, color: AppColors.orange),
                const SizedBox(height: 8),
                _MiniProgressRow(label: 'Steps', progress: stepProgress, color: AppColors.accent),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MiniProgressRow extends StatelessWidget {
  final String label;
  final double progress;
  final Color color;
  const _MiniProgressRow({required this.label, required this.progress, required this.color});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(width: 56, child: Text(label, style: const TextStyle(fontSize: 12, color: AppColors.textMuted))),
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: TweenAnimationBuilder<double>(
              duration: const Duration(milliseconds: 700),
              curve: Curves.easeOutCubic,
              tween: Tween(begin: 0, end: progress),
              builder: (context, value, _) => LinearProgressIndicator(
                value: value,
                minHeight: 7,
                backgroundColor: AppColors.border,
                valueColor: AlwaysStoppedAnimation(color),
              ),
            ),
          ),
        ),
        SizedBox(
          width: 36,
          child: TweenAnimationBuilder<double>(
            duration: const Duration(milliseconds: 700),
            curve: Curves.easeOutCubic,
            tween: Tween(begin: 0, end: progress * 100),
            builder: (context, value, _) => Text('${value.round()}%', textAlign: TextAlign.right, style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
          ),
        ),
      ],
    );
  }
}

class _LiveDot extends StatefulWidget {
  final bool active;
  const _LiveDot({required this.active});
  @override
  State<_LiveDot> createState() => _LiveDotState();
}

class _LiveDotState extends State<_LiveDot> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..repeat(reverse: true);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.active) {
      return const SizedBox(width: 8, height: 8);
    }
    return FadeTransition(
      opacity: Tween(begin: 0.3, end: 1.0).animate(_controller),
      child: Container(
        width: 8, height: 8,
        decoration: const BoxDecoration(color: AppColors.green, shape: BoxShape.circle),
      ),
    );
  }
}

class _WalkingBadge extends StatelessWidget {
  const _WalkingBadge();
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(color: AppColors.green.withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
      child: const Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.directions_run_rounded, size: 14, color: AppColors.green),
        SizedBox(width: 6),
        Text('Moving now — counting live', style: TextStyle(fontSize: 11, color: AppColors.green, fontWeight: FontWeight.w600)),
      ]),
    );
  }
}

class _ActivityCard extends StatelessWidget {
  final IconData icon;
  final String title, subtitle, value;
  const _ActivityCard({required this.icon, required this.title, required this.subtitle, required this.value});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(16)),
      child: Row(children: [
        Icon(icon, color: AppColors.orange),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
              Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
            ],
          ),
        ),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
      ]),
    );
  }
}
