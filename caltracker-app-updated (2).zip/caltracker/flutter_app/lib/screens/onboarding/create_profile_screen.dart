import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/profile_provider.dart';

class CreateProfileScreen extends ConsumerStatefulWidget {
  const CreateProfileScreen({super.key});
  @override
  ConsumerState<CreateProfileScreen> createState() => _CreateProfileScreenState();
}

class _CreateProfileScreenState extends ConsumerState<CreateProfileScreen> {
  final _pageController = PageController();
  int _step = 0;
  static const _totalSteps = 5;
  bool _submitting = false;
  String? _error;

  final _nameController = TextEditingController();
  final _heightController = TextEditingController();
  final _weightController = TextEditingController();
  DateTime? _dob;
  String _gender = 'other';
  String _goal = 'maintain';
  String _activityLevel = 'moderate';

  void _next() {
    if (_step == 0 && _nameController.text.trim().isEmpty) return _showError('Enter your name');
    if (_step == 1 && _dob == null) return _showError('Select your date of birth');
    if (_step == 2 && _heightController.text.trim().isEmpty) return _showError('Enter your height');
    if (_step == 3 && _weightController.text.trim().isEmpty) return _showError('Enter your weight');

    setState(() => _error = null);
    if (_step < _totalSteps - 1) {
      setState(() => _step++);
      _pageController.animateToPage(_step, duration: const Duration(milliseconds: 280), curve: Curves.easeOut);
    } else {
      _submit();
    }
  }

  void _back() {
    if (_step == 0) return;
    setState(() => _step--);
    _pageController.animateToPage(_step, duration: const Duration(milliseconds: 280), curve: Curves.easeOut);
  }

  void _showError(String msg) => setState(() => _error = msg);

  Future<void> _submit() async {
    setState(() => _submitting = true);
    try {
      await ref.read(profileProvider.notifier).createProfile(
        name: _nameController.text.trim(),
        dateOfBirth: _dob!,
        gender: _gender,
        heightCm: double.parse(_heightController.text.trim()),
        weightKg: double.parse(_weightController.text.trim()),
        goal: _goal,
        activityLevel: _activityLevel,
      );
    } catch (e) {
      setState(() => _error = 'Something went wrong saving your profile locally. Please try again.');
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(children: [
                    const Icon(Icons.show_chart_rounded, color: AppColors.accent),
                    const SizedBox(width: 8),
                    Text('CalTracker AI', style: Theme.of(context).textTheme.titleLarge),
                  ]),
                  if (_step > 0) IconButton(onPressed: _back, icon: const Icon(Icons.arrow_back)),
                ],
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('STEP ${_step + 1} OF $_totalSteps',
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 0.5, color: AppColors.textMuted)),
                  Text('${(((_step + 1) / _totalSteps) * 100).round()}%', style: const TextStyle(fontWeight: FontWeight.w700)),
                ],
              ),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: LinearProgressIndicator(
                  value: (_step + 1) / _totalSteps,
                  minHeight: 6,
                  backgroundColor: AppColors.border,
                  valueColor: const AlwaysStoppedAnimation(AppColors.accent),
                ),
              ),
              const SizedBox(height: 28),
              Expanded(
                child: PageView(
                  controller: _pageController,
                  physics: const NeverScrollableScrollPhysics(),
                  children: [
                    _StepWrapper(
                      title: 'Create Your Profile',
                      subtitle: "Let's set up your personalized health profile.",
                      child: _NameStep(controller: _nameController),
                    ),
                    _StepWrapper(
                      title: 'When were you born?',
                      subtitle: 'Used to calculate your calorie needs accurately.',
                      child: _DOBStep(selected: _dob, onSelect: (d) => setState(() => _dob = d), gender: _gender, onGender: (g) => setState(() => _gender = g)),
                    ),
                    _StepWrapper(
                      title: 'How tall are you?',
                      subtitle: 'Height in centimeters.',
                      child: _NumberStep(controller: _heightController, hint: 'e.g. 175', suffix: 'cm'),
                    ),
                    _StepWrapper(
                      title: "What's your current weight?",
                      subtitle: 'Weight in kilograms.',
                      child: _NumberStep(controller: _weightController, hint: 'e.g. 70', suffix: 'kg'),
                    ),
                    _StepWrapper(
                      title: "What's your goal?",
                      subtitle: 'This shapes your daily calorie and macro targets.',
                      child: _GoalStep(
                        goal: _goal,
                        onGoal: (g) => setState(() => _goal = g),
                        activityLevel: _activityLevel,
                        onActivity: (a) => setState(() => _activityLevel = a),
                      ),
                    ),
                  ],
                ),
              ),
              if (_error != null) Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Text(_error!, style: const TextStyle(color: AppColors.red, fontWeight: FontWeight.w600)),
              ),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _submitting ? null : _next,
                  child: _submitting
                      ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                      : Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(_step == _totalSteps - 1 ? 'Finish' : 'Continue'),
                            const SizedBox(width: 8),
                            const Icon(Icons.arrow_forward, size: 18),
                          ],
                        ),
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}

class _StepWrapper extends StatelessWidget {
  final String title, subtitle;
  final Widget child;
  const _StepWrapper({required this.title, required this.subtitle, required this.child});
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 6),
          Text(subtitle, style: const TextStyle(color: AppColors.textMuted, fontSize: 15)),
          const SizedBox(height: 24),
          child,
        ],
      ),
    );
  }
}

class _FieldCard extends StatelessWidget {
  final String label;
  final Widget child;
  const _FieldCard({required this.label, required this.child});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(18)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label.toUpperCase(), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 0.5, color: AppColors.textMuted)),
          const SizedBox(height: 10),
          child,
        ],
      ),
    );
  }
}

class _NameStep extends StatelessWidget {
  final TextEditingController controller;
  const _NameStep({required this.controller});
  @override
  Widget build(BuildContext context) {
    return _FieldCard(
      label: 'Full name',
      child: TextField(controller: controller, decoration: const InputDecoration(hintText: 'Enter your name')),
    );
  }
}

class _NumberStep extends StatelessWidget {
  final TextEditingController controller;
  final String hint, suffix;
  const _NumberStep({required this.controller, required this.hint, required this.suffix});
  @override
  Widget build(BuildContext context) {
    return _FieldCard(
      label: suffix == 'cm' ? 'Height' : 'Weight',
      child: TextField(
        controller: controller,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: InputDecoration(hintText: hint, suffixText: suffix),
      ),
    );
  }
}

class _DOBStep extends StatelessWidget {
  final DateTime? selected;
  final ValueChanged<DateTime> onSelect;
  final String gender;
  final ValueChanged<String> onGender;
  const _DOBStep({required this.selected, required this.onSelect, required this.gender, required this.onGender});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _FieldCard(
          label: 'Date of birth',
          child: InkWell(
            onTap: () async {
              final picked = await showDatePicker(
                context: context,
                initialDate: DateTime(2000, 1, 1),
                firstDate: DateTime(1930),
                lastDate: DateTime.now(),
              );
              if (picked != null) onSelect(picked);
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(color: AppColors.surfaceAlt, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.border)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(selected == null ? 'Select date' : '${selected!.year}-${selected!.month.toString().padLeft(2, '0')}-${selected!.day.toString().padLeft(2, '0')}'),
                  const Icon(Icons.calendar_today_outlined, size: 18),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
        _FieldCard(
          label: 'Gender',
          child: Wrap(
            spacing: 10,
            children: ['male', 'female', 'other'].map((g) {
              final isSelected = gender == g;
              return ChoiceChip(
                label: Text(g[0].toUpperCase() + g.substring(1)),
                selected: isSelected,
                onSelected: (_) => onGender(g),
                selectedColor: AppColors.accent,
                labelStyle: TextStyle(color: isSelected ? Colors.white : AppColors.text, fontWeight: FontWeight.w600),
                backgroundColor: AppColors.surfaceAlt,
                shape: StadiumBorder(side: BorderSide(color: AppColors.border)),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }
}

class _GoalStep extends StatelessWidget {
  final String goal;
  final ValueChanged<String> onGoal;
  final String activityLevel;
  final ValueChanged<String> onActivity;
  const _GoalStep({required this.goal, required this.onGoal, required this.activityLevel, required this.onActivity});

  static const _goals = {'lose': 'Lose weight', 'maintain': 'Maintain', 'gain': 'Gain muscle'};
  static const _activities = {
    'sedentary': 'Sedentary',
    'light': 'Lightly active',
    'moderate': 'Moderately active',
    'active': 'Active',
    'very_active': 'Very active',
  };

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _FieldCard(
          label: 'Goal',
          child: Wrap(
            spacing: 10,
            runSpacing: 10,
            children: _goals.entries.map((e) {
              final isSelected = goal == e.key;
              return ChoiceChip(
                label: Text(e.value),
                selected: isSelected,
                onSelected: (_) => onGoal(e.key),
                selectedColor: AppColors.accent,
                labelStyle: TextStyle(color: isSelected ? Colors.white : AppColors.text, fontWeight: FontWeight.w600),
                backgroundColor: AppColors.surfaceAlt,
                shape: const StadiumBorder(side: BorderSide(color: AppColors.border)),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 16),
        _FieldCard(
          label: 'Activity level',
          child: Column(
            children: _activities.entries.map((e) {
              return RadioListTile<String>(
                value: e.key,
                groupValue: activityLevel,
                onChanged: (v) => onActivity(v!),
                title: Text(e.value),
                activeColor: AppColors.accent,
                contentPadding: EdgeInsets.zero,
                dense: true,
              );
            }).toList(),
          ),
        ),
      ],
    );
  }
}
