import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../../services/settings_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _controller = TextEditingController();
  bool _saved = false;

  @override
  void initState() {
    super.initState();
    SettingsService.getApiKey().then((key) => setState(() => _controller.text = key ?? ''));
  }

  Future<void> _save() async {
    await SettingsService.saveApiKey(_controller.text.trim());
    setState(() => _saved = true);
    Future.delayed(const Duration(seconds: 2), () { if (mounted) setState(() => _saved = false); });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Anthropic API key', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
              const SizedBox(height: 6),
              const Text(
                'Needed for AI food scanning. Stored only on this device. Get one at console.anthropic.com.',
                style: TextStyle(color: AppColors.textMuted, fontSize: 13),
              ),
              const SizedBox(height: 14),
              TextField(controller: _controller, obscureText: true, decoration: const InputDecoration(hintText: 'sk-ant-...')),
              const SizedBox(height: 14),
              SizedBox(width: double.infinity, child: ElevatedButton(onPressed: _save, child: Text(_saved ? 'Saved ✓' : 'Save'))),
              const SizedBox(height: 24),
              const Divider(),
              const SizedBox(height: 12),
              const Text('About storage', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              const Text(
                'All your profile, meal logs, weight, and activity data is stored only on this device (SQLite). '
                'There is no server and no account — uninstalling the app or resetting your profile permanently deletes this data.',
                style: TextStyle(color: AppColors.textMuted, fontSize: 13),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
