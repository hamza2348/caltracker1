import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/profile_provider.dart';
import '../../services/logs_service.dart';
import '../scan/scan_food_screen.dart';
import '../barcode/barcode_scan_screen.dart';
import '../manual_entry/manual_entry_screen.dart';
import '../favorites/favorites_screen.dart';
import 'package:intl/intl.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});
  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  Map<String, dynamic>? _totals;
  List<dynamic> _logs = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final logs = await LogsService.logsForDate(today);
    final totals = await LogsService.totalsForDate(today);
    setState(() {
      _logs = logs;
      _totals = totals;
      _loading = false;
    });
  }

  Future<void> _openAndRefresh(Widget screen) async {
    final result = await Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
    if (result == true) _load();
  }

  @override
  Widget build(BuildContext context) {
    final profile = ref.watch(profileProvider).profile;
    final goal = profile?.dailyCalorieGoal ?? 2000;
    final consumed = (_totals?['calories'] ?? 0) as int;
    final left = (goal - consumed).clamp(0, goal);
    final macros = {
      'protein': profile?.proteinGoal ?? 150,
      'carbs': profile?.carbsGoal ?? 200,
      'fat': profile?.fatGoal ?? 60,
    };

    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _load,
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Row(children: [
                const Icon(Icons.show_chart_rounded),
                const SizedBox(width: 8),
                Text('CalTracker', style: Theme.of(context).textTheme.titleLarge),
                const Spacer(),
                Text('Hi, ${profile?.name.split(' ').first ?? ''}', style: const TextStyle(color: AppColors.textMuted)),
              ]),
              const SizedBox(height: 20),
              _FadeSlideIn(
                delay: 0,
                child: Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(20), boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.35), blurRadius: 14, offset: const Offset(0, 4)),
                ]),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('$left', style: const TextStyle(fontSize: 40, fontWeight: FontWeight.w800)),
                          const Text('Calories left', style: TextStyle(color: AppColors.textMuted)),
                          const SizedBox(height: 10),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(6),
                            child: TweenAnimationBuilder<double>(
                              duration: const Duration(milliseconds: 600),
                              curve: Curves.easeOutCubic,
                              tween: Tween(begin: 0, end: goal == 0 ? 0 : (consumed / goal).clamp(0, 1).toDouble()),
                              builder: (context, value, _) => LinearProgressIndicator(
                                value: value,
                                minHeight: 8,
                                backgroundColor: AppColors.border,
                                valueColor: const AlwaysStoppedAnimation(AppColors.accent),
                              ),
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text('$consumed of $goal kcal', style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 76,
                      height: 76,
                      child: Stack(alignment: Alignment.center, children: [
                        TweenAnimationBuilder<double>(
                          duration: const Duration(milliseconds: 600),
                          curve: Curves.easeOutCubic,
                          tween: Tween(begin: 0, end: goal == 0 ? 0 : (consumed / goal).clamp(0, 1).toDouble()),
                          builder: (context, value, _) => CircularProgressIndicator(
                            value: value,
                            strokeWidth: 6,
                            backgroundColor: AppColors.border,
                            valueColor: const AlwaysStoppedAnimation(AppColors.orange),
                          ),
                        ),
                        const Icon(Icons.local_fire_department_rounded, color: AppColors.orange),
                      ]),
                    ),
                  ],
                ),
              )),
              const SizedBox(height: 16),
              Row(
                children: [
                  _QuickAction(icon: Icons.add_circle_outline_rounded, label: 'Quick Add', onTap: () => _openAndRefresh(const ManualEntryScreen())),
                  _QuickAction(icon: Icons.camera_alt_outlined, label: 'AI Scan', onTap: () => _openAndRefresh(const ScanFoodScreen())),
                  _QuickAction(icon: Icons.qr_code_scanner_rounded, label: 'Barcode', onTap: () => _openAndRefresh(const BarcodeScanScreen())),
                  _QuickAction(icon: Icons.favorite_border_rounded, label: 'Favorites', onTap: () => _openAndRefresh(const FavoritesScreen())),
                ],
              ),
              const SizedBox(height: 16),
              _FadeSlideIn(
                delay: 100,
                child: Row(
                  children: [
                    _MacroCard(label: 'Protein', value: _totals?['protein'] ?? 0, goal: macros['protein'] ?? 0),
                    const SizedBox(width: 10),
                    _MacroCard(label: 'Carbs', value: _totals?['carbs'] ?? 0, goal: macros['carbs'] ?? 0),
                    const SizedBox(width: 10),
                    _MacroCard(label: 'Fat', value: _totals?['fat'] ?? 0, goal: macros['fat'] ?? 0),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              Text('Today\'s meals', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 12),
              if (_loading) const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator())),
              if (!_loading && _logs.isEmpty)
                const Padding(padding: EdgeInsets.all(16), child: Text('No meals logged yet today. Tap the scan button to add one.', style: TextStyle(color: AppColors.textMuted))),
              ..._logs.asMap().entries.map((entry) => _FadeSlideIn(
                    delay: 160 + entry.key * 40,
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14)),
                      child: Row(
                        children: [
                          Expanded(child: Text(entry.value['name'], style: const TextStyle(fontWeight: FontWeight.w600))),
                          Text('${entry.value['calories']} kcal', style: const TextStyle(color: AppColors.textMuted)),
                        ],
                      ),
                    ),
                  )),
            ],
          ),
        ),
      ),
    );
  }
}

class _MacroCard extends StatelessWidget {
  final String label;
  final num value, goal;
  const _MacroCard({required this.label, required this.value, required this.goal});
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('$value/${goal}g', style: const TextStyle(fontWeight: FontWeight.w700)),
            Text(label, style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
            const SizedBox(height: 6),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: TweenAnimationBuilder<double>(
                duration: const Duration(milliseconds: 600),
                curve: Curves.easeOutCubic,
                tween: Tween(begin: 0, end: goal == 0 ? 0 : (value / goal).clamp(0, 1).toDouble()),
                builder: (context, v, _) => LinearProgressIndicator(
                  value: v,
                  minHeight: 5,
                  backgroundColor: AppColors.border,
                  valueColor: const AlwaysStoppedAnimation(AppColors.accent),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _QuickAction extends StatefulWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _QuickAction({required this.icon, required this.label, required this.onTap});
  @override
  State<_QuickAction> createState() => _QuickActionState();
}

class _QuickActionState extends State<_QuickAction> {
  double _scale = 1;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTapDown: (_) => setState(() => _scale = 0.9),
        onTapUp: (_) => setState(() => _scale = 1),
        onTapCancel: () => setState(() => _scale = 1),
        onTap: widget.onTap,
        child: AnimatedScale(
          scale: _scale,
          duration: const Duration(milliseconds: 120),
          curve: Curves.easeOut,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: const BoxDecoration(color: AppColors.surfaceAlt, shape: BoxShape.circle),
                  child: Icon(widget.icon, color: AppColors.accent, size: 20),
                ),
                const SizedBox(height: 6),
                Text(widget.label, style: const TextStyle(fontSize: 11, color: AppColors.textMuted), textAlign: TextAlign.center),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Simple fade + slide-up entrance used to stagger cards in on load.
class _FadeSlideIn extends StatefulWidget {
  final Widget child;
  final int delay;
  const _FadeSlideIn({required this.child, this.delay = 0});
  @override
  State<_FadeSlideIn> createState() => _FadeSlideInState();
}

class _FadeSlideInState extends State<_FadeSlideIn> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 420));

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: widget.delay), () {
      if (mounted) _controller.forward();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final curved = CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic);
    return FadeTransition(
      opacity: curved,
      child: SlideTransition(
        position: Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero).animate(curved),
        child: widget.child,
      ),
    );
  }
}
