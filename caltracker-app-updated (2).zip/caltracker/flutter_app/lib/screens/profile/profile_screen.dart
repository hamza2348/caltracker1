import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/profile_provider.dart';
import '../settings/settings_screen.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  Future<void> _confirmReset(BuildContext context, WidgetRef ref) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Reset profile?'),
        content: const Text('This deletes your profile and starts over. This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Reset', style: TextStyle(color: AppColors.red))),
        ],
      ),
    );
    if (confirmed == true) {
      await ref.read(profileProvider.notifier).resetProfile();
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(profileProvider).profile;
    final initials = (profile?.name ?? '?').trim().split(' ').map((s) => s.isNotEmpty ? s[0] : '').take(2).join().toUpperCase();

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Center(
              child: Column(children: [
                CircleAvatar(radius: 36, backgroundColor: AppColors.accent, child: Text(initials, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w700))),
                const SizedBox(height: 10),
                Text(profile?.name ?? '', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                if (profile != null) Text('${profile.age} years old', style: const TextStyle(color: AppColors.textMuted)),
              ]),
            ),
            const SizedBox(height: 24),
            _InfoCard(icon: Icons.monitor_weight_outlined, label: 'Current weight', value: '${profile?.weightKg ?? '-'} kg'),
            _InfoCard(icon: Icons.height_rounded, label: 'Height', value: '${profile?.heightCm ?? '-'} cm'),
            _InfoCard(icon: Icons.flag_outlined, label: 'Goal', value: profile?.goal ?? '-'),
            _InfoCard(icon: Icons.local_fire_department_outlined, label: 'Daily calorie target', value: '${profile?.dailyCalorieGoal ?? '-'} kcal'),
            _InfoCard(icon: Icons.directions_run_rounded, label: 'Activity level', value: profile?.activityLevel ?? '-'),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SettingsScreen())),
                icon: const Icon(Icons.settings_outlined),
                label: const Text('Settings'),
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: () => _confirmReset(context, ref),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.red,
                  side: const BorderSide(color: AppColors.red),
                  minimumSize: const Size.fromHeight(52),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
                ),
                child: const Text('Reset profile'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final IconData icon;
  final String label, value;
  const _InfoCard({required this.icon, required this.label, required this.value});
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14)),
      child: Row(children: [
        Icon(icon, color: AppColors.textMuted),
        const SizedBox(width: 12),
        Expanded(child: Text(label)),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w700)),
      ]),
    );
  }
}
