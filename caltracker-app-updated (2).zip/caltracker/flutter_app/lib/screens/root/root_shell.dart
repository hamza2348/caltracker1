import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../dashboard/home_screen.dart';
import '../history/history_screen.dart';
import '../profile/profile_screen.dart';
import '../progress/progress_screen.dart';
import '../scan/scan_food_screen.dart';
import '../barcode/barcode_scan_screen.dart';
import '../manual_entry/manual_entry_screen.dart';

class RootShell extends StatefulWidget {
  const RootShell({super.key});
  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int _index = 0;
  final _screens = const [HomeScreen(), ProgressScreen(), HistoryScreen(), ProfileScreen()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 220),
        child: KeyedSubtree(key: ValueKey(_index), child: _screens[_index]),
      ),
      floatingActionButton: _ScanFab(),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.bar_chart_rounded), label: 'Progress'),
          BottomNavigationBarItem(icon: Icon(Icons.history_rounded), label: 'History'),
          BottomNavigationBarItem(icon: Icon(Icons.person_rounded), label: 'Profile'),
        ],
      ),
    );
  }
}

/// Tap to expand into three choices: AI photo scan, barcode scan, or manual entry.
/// The FAB icon rotates into a close (X) and the actions scale/fade in staggered.
class _ScanFab extends StatefulWidget {
  @override
  State<_ScanFab> createState() => _ScanFabState();
}

class _ScanFabState extends State<_ScanFab> with SingleTickerProviderStateMixin {
  bool _open = false;
  late final AnimationController _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 260));

  void _toggle() {
    setState(() => _open = !_open);
    if (_open) {
      _controller.forward();
    } else {
      _controller.reverse();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Widget _staggeredAction({required int index, required Widget child}) {
    final start = index * 0.12;
    final animation = CurvedAnimation(
      parent: _controller,
      curve: Interval(start.clamp(0, 1), 1.0, curve: Curves.easeOutBack),
    );
    return ScaleTransition(
      scale: animation,
      child: FadeTransition(opacity: _controller, child: child),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (_open) ...[
          _staggeredAction(
            index: 2,
            child: _MiniAction(
              icon: Icons.edit_note_rounded,
              label: 'Manual entry (offline)',
              onTap: () {
                _toggle();
                Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ManualEntryScreen()));
              },
            ),
          ),
          const SizedBox(height: 10),
          _staggeredAction(
            index: 1,
            child: _MiniAction(
              icon: Icons.qr_code_scanner_rounded,
              label: 'Barcode scan',
              onTap: () {
                _toggle();
                Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BarcodeScanScreen()));
              },
            ),
          ),
          const SizedBox(height: 10),
          _staggeredAction(
            index: 0,
            child: _MiniAction(
              icon: Icons.camera_alt_rounded,
              label: 'AI photo scan',
              onTap: () {
                _toggle();
                Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ScanFoodScreen()));
              },
            ),
          ),
          const SizedBox(height: 10),
        ],
        FloatingActionButton(
          shape: const CircleBorder(),
          onPressed: _toggle,
          child: AnimatedRotation(
            turns: _open ? 0.125 : 0,
            duration: const Duration(milliseconds: 260),
            curve: Curves.easeOutBack,
            child: Icon(_open ? Icons.close_rounded : Icons.qr_code_scanner_rounded),
          ),
        ),
      ],
    );
  }
}

class _MiniAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _MiniAction({required this.icon, required this.label, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(24),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(24), boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 10, offset: const Offset(0, 3)),
        ]),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 18, color: AppColors.accent),
          const SizedBox(width: 8),
          Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
        ]),
      ),
    );
  }
}
