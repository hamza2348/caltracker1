import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_theme.dart';
import '../../models/food_item.dart';
import '../../services/vision_scan_service.dart';
import '../../services/logs_service.dart';
import '../settings/settings_screen.dart';

class ScanFoodScreen extends StatefulWidget {
  const ScanFoodScreen({super.key});
  @override
  State<ScanFoodScreen> createState() => _ScanFoodScreenState();
}

class _ScanFoodScreenState extends State<ScanFoodScreen> {
  File? _image;
  bool _analyzing = false;
  double _progress = 0;
  String _progressLabel = '';
  List<ScannedFoodItem> _items = [];
  String? _error;
  String _mealType = 'lunch';

  Future<void> _pickImage(ImageSource source) async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: source, imageQuality: 85);
    if (picked == null) return;
    setState(() {
      _image = File(picked.path);
      _items = [];
      _error = null;
    });
    _analyze();
  }

  Future<void> _analyze() async {
    if (_image == null) return;
    setState(() {
      _analyzing = true;
      _progress = 0;
      _progressLabel = 'Preparing image...';
    });
    try {
      final bytes = await _image!.readAsBytes();
      final base64Image = base64Encode(bytes);
      final mediaType = _image!.path.toLowerCase().endsWith('.png') ? 'image/png' : 'image/jpeg';
      final results = await VisionScanService.scanImage(
        base64Image,
        mediaType,
        onProgress: (p, label) {
          if (!mounted) return;
          setState(() {
            _progress = p;
            _progressLabel = label;
          });
        },
      );
      final items = results.map((e) => ScannedFoodItem.fromJson(e)).toList();
      setState(() => _items = items);
    } on VisionScanException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = 'Could not analyze the photo. Check your connection and try again.');
    } finally {
      if (mounted) setState(() => _analyzing = false);
    }
  }

  int get _selectedTotal => _items.where((i) => i.selected).fold(0, (sum, i) => sum + (i.calories ?? 0));
  int get _selectedCount => _items.where((i) => i.selected).length;

  Future<void> _addToLog() async {
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
    for (final item in _items.where((i) => i.selected && !i.needsManualEntry)) {
      await LogsService.addLog(
        name: item.name,
        quantityGrams: item.estimatedGrams,
        calories: item.calories!,
        protein: item.protein ?? 0,
        carbs: item.carbs ?? 0,
        fat: item.fat ?? 0,
        mealType: _mealType,
        date: today,
      );
    }
    if (mounted) Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Food Scanner'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SettingsScreen())),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            if (_image == null) _CaptureCard(onCamera: () => _pickImage(ImageSource.camera), onGallery: () => _pickImage(ImageSource.gallery)),
            if (_image != null) ...[
              ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: Stack(children: [
                  Image.file(_image!, height: 240, width: double.infinity, fit: BoxFit.cover),
                  Positioned(
                    top: 10, right: 10,
                    child: Row(children: [
                      _ChipButton(icon: Icons.camera_alt_outlined, label: 'Retake', onTap: () => _pickImage(ImageSource.camera)),
                      const SizedBox(width: 8),
                      _ChipButton(icon: Icons.photo_outlined, label: 'Gallery', onTap: () => _pickImage(ImageSource.gallery)),
                    ]),
                  ),
                ]),
              ),
              const SizedBox(height: 16),
              if (_analyzing) _ScanProgress(progress: _progress, label: _progressLabel),
              if (_error != null) Padding(padding: const EdgeInsets.all(16), child: Text(_error!, style: const TextStyle(color: AppColors.red))),
              if (!_analyzing && _items.isNotEmpty) ...[
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  const Text('Detected foods', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                  Text('${_items.length} items', style: const TextStyle(color: AppColors.textMuted)),
                ]),
                const Text('Tap items to select/deselect, adjust grams if a portion looks off', style: TextStyle(fontSize: 12, color: AppColors.textMuted)),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14)),
                  child: Row(children: [
                    const Icon(Icons.local_fire_department_rounded, color: AppColors.orange),
                    const SizedBox(width: 10),
                    Text('Total ($_selectedCount items)', style: const TextStyle(color: AppColors.textMuted)),
                    const Spacer(),
                    Text('$_selectedTotal kcal', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                  ]),
                ),
                const SizedBox(height: 12),
                ..._items.asMap().entries.map((entry) => _FadeSlideIn(
                      delay: entry.key * 60,
                      child: _FoodItemCard(
                        item: entry.value,
                        onToggle: () => setState(() => entry.value.selected = !entry.value.selected),
                        onGramsChanged: (grams) {
                          // Recalculate proportionally when user adjusts the estimated portion
                          setState(() {
                            final item = entry.value;
                            final ratio = grams / item.estimatedGrams;
                            _items[entry.key] = ScannedFoodItem(
                              name: item.name,
                              description: item.description,
                              confidence: item.confidence,
                              estimatedGrams: grams,
                              calories: item.calories == null ? null : (item.calories! * ratio).round(),
                              protein: item.protein == null ? null : (item.protein! * ratio).round(),
                              carbs: item.carbs == null ? null : (item.carbs! * ratio).round(),
                              fat: item.fat == null ? null : (item.fat! * ratio).round(),
                              source: item.source,
                              selected: item.selected,
                            );
                          });
                        },
                      ),
                    )),
                const SizedBox(height: 16),
                Wrap(spacing: 8, children: ['breakfast', 'lunch', 'dinner', 'snack'].map((m) {
                  final isSelected = _mealType == m;
                  return ChoiceChip(
                    label: Text(m[0].toUpperCase() + m.substring(1)),
                    selected: isSelected,
                    onSelected: (_) => setState(() => _mealType = m),
                    selectedColor: AppColors.accent,
                    labelStyle: TextStyle(color: isSelected ? Colors.white : AppColors.text),
                    backgroundColor: AppColors.surfaceAlt,
                  );
                }).toList()),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _selectedCount == 0 ? null : _addToLog,
                    child: Text('Add to ${_mealType[0].toUpperCase()}${_mealType.substring(1)}  ·  $_selectedTotal kcal'),
                  ),
                ),
              ],
            ],
          ],
        ),
      ),
    );
  }
}

/// Real progress — driven by the actual upload/AI/database-check stages in
/// VisionScanService, not a fake timer.
class _ScanProgress extends StatelessWidget {
  final double progress;
  final String label;
  const _ScanProgress({required this.progress, required this.label});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(16)),
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: TweenAnimationBuilder<double>(
              duration: const Duration(milliseconds: 400),
              curve: Curves.easeOutCubic,
              tween: Tween(begin: 0, end: progress),
              builder: (context, value, _) => LinearProgressIndicator(
                value: value,
                minHeight: 10,
                backgroundColor: AppColors.border,
                valueColor: const AlwaysStoppedAnimation(AppColors.accent),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(child: Text(label, style: const TextStyle(color: AppColors.textMuted, fontSize: 13))),
              Text('${(progress * 100).round()}%', style: const TextStyle(color: AppColors.textMuted, fontSize: 13, fontWeight: FontWeight.w700)),
            ],
          ),
        ],
      ),
    );
  }
}

/// Simple fade + slide-up entrance used to stagger detected food cards in.
class _FadeSlideIn extends StatefulWidget {
  final Widget child;
  final int delay;
  const _FadeSlideIn({required this.child, this.delay = 0});
  @override
  State<_FadeSlideIn> createState() => _FadeSlideInState();
}

class _FadeSlideInState extends State<_FadeSlideIn> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 380));

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: widget.delay), () {
      if (mounted) _controller.forward();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final curved = CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic);
    return FadeTransition(
      opacity: curved,
      child: SlideTransition(
        position: Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero).animate(curved),
        child: widget.child,
      ),
    );
  }
}

class _CaptureCard extends StatelessWidget {
  final VoidCallback onCamera, onGallery;
  const _CaptureCard({required this.onCamera, required this.onGallery});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(20)),
      child: Column(
        children: [
          const Icon(Icons.camera_alt_outlined, size: 48, color: AppColors.textMuted),
          const SizedBox(height: 12),
          const Text('Snap a photo of your food', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
          const SizedBox(height: 4),
          const Text('AI identifies items and estimates calories', style: TextStyle(color: AppColors.textMuted), textAlign: TextAlign.center),
          const SizedBox(height: 20),
          SizedBox(width: double.infinity, child: ElevatedButton(onPressed: onCamera, child: const Text('Take photo'))),
          const SizedBox(height: 10),
          SizedBox(width: double.infinity, child: OutlinedButton(onPressed: onGallery, child: const Text('Choose from gallery'))),
        ],
      ),
    );
  }
}

class _ChipButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _ChipButton({required this.icon, required this.label, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(20)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 14, color: Colors.white),
          const SizedBox(width: 4),
          Text(label, style: const TextStyle(color: Colors.white, fontSize: 12)),
        ]),
      ),
    );
  }
}

class _FoodItemCard extends StatelessWidget {
  final ScannedFoodItem item;
  final VoidCallback onToggle;
  final ValueChanged<double> onGramsChanged;
  const _FoodItemCard({required this.item, required this.onToggle, required this.onGramsChanged});

  @override
  Widget build(BuildContext context) {
    final confColor = item.confidence >= 75 ? AppColors.green : (item.confidence >= 50 ? AppColors.orange : AppColors.red);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: item.selected ? AppColors.accent : AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: onToggle,
                child: Icon(item.selected ? Icons.check_box_rounded : Icons.check_box_outline_blank_rounded, color: AppColors.accent),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                    if (item.description != null) Text(item.description!, style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(color: confColor.withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
                    child: Text('${item.confidence}%', style: TextStyle(fontSize: 11, color: confColor, fontWeight: FontWeight.w700)),
                  ),
                  const SizedBox(height: 4),
                  Text(item.calories != null ? '${item.calories} kcal' : 'needs input', style: const TextStyle(fontWeight: FontWeight.w700)),
                ],
              ),
            ],
          ),
          if (item.needsManualEntry)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text('No database match — tap to enter calories manually', style: TextStyle(fontSize: 12, color: AppColors.red)),
            ),
          const SizedBox(height: 8),
          Row(
            children: [
              Text('${item.estimatedGrams.round()}g', style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
              Expanded(
                child: Slider(
                  value: item.estimatedGrams.clamp(10, 800),
                  min: 10,
                  max: 800,
                  activeColor: AppColors.accent,
                  onChanged: onGramsChanged,
                ),
              ),
            ],
          ),
          if (item.protein != null)
            Text('P ${item.protein}g   C ${item.carbs}g   F ${item.fat}g', style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
        ],
      ),
    );
  }
}
