import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../../services/favorites_service.dart';
import '../manual_entry/manual_entry_screen.dart';

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});
  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  List<Map<String, dynamic>> _favorites = [];
  List<Map<String, dynamic>> _filtered = [];
  bool _loading = true;
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
    _searchController.addListener(_filter);
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final favs = await FavoritesService.all();
    setState(() {
      _favorites = favs;
      _filtered = favs;
      _loading = false;
    });
  }

  void _filter() {
    final query = _searchController.text.toLowerCase();
    setState(() => _filtered = _favorites.where((f) => (f['name'] as String).toLowerCase().contains(query)).toList());
  }

  Future<void> _delete(String id) async {
    await FavoritesService.delete(id);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Favorites')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: _searchController,
                decoration: const InputDecoration(hintText: 'Search favorites', prefixIcon: Icon(Icons.search)),
              ),
              const SizedBox(height: 16),
              if (_loading) const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator())),
              if (!_loading && _filtered.isEmpty)
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(
                    _favorites.isEmpty
                        ? 'No favorites yet. Save a food as a favorite from Manual Entry to see it here.'
                        : 'No matches.',
                    style: const TextStyle(color: AppColors.textMuted),
                  ),
                ),
              Expanded(
                child: ListView.builder(
                  itemCount: _filtered.length,
                  itemBuilder: (context, i) {
                    final f = _filtered[i];
                    return Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14)),
                      child: ListTile(
                        title: Text(f['name'], style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: Text('${f['caloriesPer100g'].round()} kcal / 100g'),
                        trailing: IconButton(icon: const Icon(Icons.delete_outline, color: AppColors.red), onPressed: () => _delete(f['id'])),
                        onTap: () async {
                          final added = await Navigator.of(context).push(MaterialPageRoute(builder: (_) => ManualEntryScreen(prefill: f)));
                          if (added == true && mounted) Navigator.of(context).pop(true);
                        },
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        
        onPressed: () async {
          final added = await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ManualEntryScreen()));
          if (added == true) _load();
        },
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }
}
