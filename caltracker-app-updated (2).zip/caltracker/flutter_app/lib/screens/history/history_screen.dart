import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/profile_provider.dart';
import '../../services/logs_service.dart';

class HistoryScreen extends ConsumerStatefulWidget {
  const HistoryScreen({super.key});
  @override
  ConsumerState<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends ConsumerState<HistoryScreen> {
  List<dynamic> _days = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final days = await LogsService.history(days: 61);
    setState(() {
      _days = days;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final calorieGoal = ref.watch(profileProvider).profile?.dailyCalorieGoal ?? 2000;
    final avgCalories = _days.isEmpty ? 0 : (_days.fold<num>(0, (s, d) => s + d['calories']) / _days.length).round();
    final totalMeals = _days.fold<num>(0, (s, d) => s + d['mealsCount']);
    final avgProtein = _days.isEmpty ? 0 : (_days.fold<num>(0, (s, d) => s + d['protein']) / _days.length).round();
    final avgCarbs = _days.isEmpty ? 0 : (_days.fold<num>(0, (s, d) => s + d['carbs']) / _days.length).round();
    final avgFat = _days.isEmpty ? 0 : (_days.fold<num>(0, (s, d) => s + d['fat']) / _days.length).round();

    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _load,
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text('History', style: Theme.of(context).textTheme.headlineMedium),
                Text('${_days.length} days', style: const TextStyle(color: AppColors.textMuted)),
              ]),
              const SizedBox(height: 16),
              Row(children: [
                _StatCard(icon: Icons.local_fire_department_rounded, value: '$avgCalories', label: 'kcal avg/day'),
                const SizedBox(width: 10),
                _StatCard(icon: Icons.check_circle_outline_rounded, value: '${_days.length}', label: 'days tracked'),
                const SizedBox(width: 10),
                _StatCard(icon: Icons.restaurant_rounded, value: '$totalMeals', label: 'meals logged'),
              ]),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _MiniStat(value: '${avgProtein}g', label: 'Protein/day'),
                    _MiniStat(value: '${avgCarbs}g', label: 'Carbs/day'),
                    _MiniStat(value: '${avgFat}g', label: 'Fat/day'),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Text('Daily logs', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 12),
              if (_loading) const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator())),
              if (!_loading && _days.isEmpty)
                const Padding(padding: EdgeInsets.all(16), child: Text('No history yet — start logging meals to see trends here.', style: TextStyle(color: AppColors.textMuted))),
              ..._days.map((d) => _DayCard(day: d, calorieGoal: calorieGoal)),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String value, label;
  const _StatCard({required this.icon, required this.value, required this.label});
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 18, color: AppColors.textMuted),
            const SizedBox(height: 8),
            Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textMuted)),
          ],
        ),
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final String value, label;
  const _MiniStat({required this.value, required this.label});
  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Text(value, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
      Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textMuted)),
    ]);
  }
}

class _DayCard extends StatelessWidget {
  final Map<String, dynamic> day;
  final int calorieGoal;
  const _DayCard({required this.day, required this.calorieGoal});
  @override
  Widget build(BuildContext context) {
    final isOver = (day['calories'] as int) > calorieGoal;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(16)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Container(
              width: 40, height: 40,
              alignment: Alignment.center,
              decoration: BoxDecoration(color: AppColors.cardGray, borderRadius: BorderRadius.circular(10)),
              child: Text(day['date'].toString().split('-').last, style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(day['date'], style: const TextStyle(fontWeight: FontWeight.w700)),
                  Text('${day['mealsCount']} meals logged', style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
                ],
              ),
            ),
            Text('${day['calories']} kcal', style: TextStyle(fontWeight: FontWeight.w800, color: isOver ? AppColors.red : AppColors.green)),
          ]),
          const SizedBox(height: 8),
          Text('P: ${day['protein']}g   C: ${day['carbs']}g   F: ${day['fat']}g', style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
        ],
      ),
    );
  }
}
