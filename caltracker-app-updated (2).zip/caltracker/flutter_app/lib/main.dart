import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/theme/app_theme.dart';
import 'providers/profile_provider.dart';
import 'screens/splash/splash_screen.dart';
import 'screens/onboarding/create_profile_screen.dart';
import 'screens/root/root_shell.dart';

void main() {
  runApp(const ProviderScope(child: CalTrackerApp()));
}

class CalTrackerApp extends StatelessWidget {
  const CalTrackerApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CalTracker AI',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark(),
      darkTheme: AppTheme.dark(),
      themeMode: ThemeMode.dark,
      home: const _RootRouter(),
    );
  }
}

// This is the entire "auth" logic: check saved profile status and route
// straight to Home if found, otherwise show Create Profile. No login screen.
class _RootRouter extends ConsumerWidget {
  const _RootRouter();
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(profileProvider);
    switch (state.status) {
      case ProfileStatus.loading:
        return const SplashScreen();
      case ProfileStatus.noProfile:
        return const CreateProfileScreen();
      case ProfileStatus.ready:
        return const RootShell();
    }
  }
}
