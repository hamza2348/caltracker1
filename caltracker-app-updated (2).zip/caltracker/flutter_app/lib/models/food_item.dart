class ScannedFoodItem {
  final String name;
  final String? description;
  final int confidence;
  final double estimatedGrams;
  final int? calories;
  final int? protein;
  final int? carbs;
  final int? fat;
  final String source; // database_matched | unmatched_needs_manual_entry
  bool selected;

  ScannedFoodItem({
    required this.name,
    this.description,
    required this.confidence,
    required this.estimatedGrams,
    this.calories,
    this.protein,
    this.carbs,
    this.fat,
    required this.source,
    this.selected = true,
  });

  factory ScannedFoodItem.fromJson(Map<String, dynamic> json) => ScannedFoodItem(
        name: json['name'],
        description: json['description'],
        confidence: json['confidence'] ?? 0,
        estimatedGrams: (json['estimatedGrams'] as num).toDouble(),
        calories: json['calories'],
        protein: json['protein'],
        carbs: json['carbs'],
        fat: json['fat'],
        source: json['source'] ?? 'unmatched_needs_manual_entry',
      );

  bool get needsManualEntry => calories == null;
}
