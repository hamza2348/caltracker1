class UserProfile {
  final String name;
  final DateTime dateOfBirth;
  final String gender;
  final double heightCm;
  final double weightKg;
  final double? goalWeightKg;
  final String goal; // lose | maintain | gain
  final String activityLevel;
  final int dailyCalorieGoal;
  final int proteinGoal;
  final int carbsGoal;
  final int fatGoal;

  UserProfile({
    required this.name,
    required this.dateOfBirth,
    required this.gender,
    required this.heightCm,
    required this.weightKg,
    this.goalWeightKg,
    required this.goal,
    required this.activityLevel,
    required this.dailyCalorieGoal,
    required this.proteinGoal,
    required this.carbsGoal,
    required this.fatGoal,
  });

  int get age {
    final now = DateTime.now();
    int age = now.year - dateOfBirth.year;
    if (now.month < dateOfBirth.month || (now.month == dateOfBirth.month && now.day < dateOfBirth.day)) age--;
    return age;
  }

  Map<String, dynamic> toDbMap() => {
        'id': 1,
        'name': name,
        'dateOfBirth': dateOfBirth.toIso8601String(),
        'gender': gender,
        'heightCm': heightCm,
        'weightKg': weightKg,
        'goalWeightKg': goalWeightKg,
        'goal': goal,
        'activityLevel': activityLevel,
        'dailyCalorieGoal': dailyCalorieGoal,
        'proteinGoal': proteinGoal,
        'carbsGoal': carbsGoal,
        'fatGoal': fatGoal,
      };

  factory UserProfile.fromDbMap(Map<String, dynamic> map) => UserProfile(
        name: map['name'],
        dateOfBirth: DateTime.parse(map['dateOfBirth']),
        gender: map['gender'],
        heightCm: (map['heightCm'] as num).toDouble(),
        weightKg: (map['weightKg'] as num).toDouble(),
        goalWeightKg: map['goalWeightKg'] != null ? (map['goalWeightKg'] as num).toDouble() : null,
        goal: map['goal'],
        activityLevel: map['activityLevel'],
        dailyCalorieGoal: map['dailyCalorieGoal'],
        proteinGoal: map['proteinGoal'],
        carbsGoal: map['carbsGoal'],
        fatGoal: map['fatGoal'],
      );

  UserProfile copyWith({double? weightKg, String? goal, String? activityLevel, int? dailyCalorieGoal, int? proteinGoal, int? carbsGoal, int? fatGoal}) {
    return UserProfile(
      name: name,
      dateOfBirth: dateOfBirth,
      gender: gender,
      heightCm: heightCm,
      weightKg: weightKg ?? this.weightKg,
      goalWeightKg: goalWeightKg,
      goal: goal ?? this.goal,
      activityLevel: activityLevel ?? this.activityLevel,
      dailyCalorieGoal: dailyCalorieGoal ?? this.dailyCalorieGoal,
      proteinGoal: proteinGoal ?? this.proteinGoal,
      carbsGoal: carbsGoal ?? this.carbsGoal,
      fatGoal: fatGoal ?? this.fatGoal,
    );
  }
}
