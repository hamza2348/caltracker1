import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/db/local_store.dart';
import '../core/calc/goal_calculator.dart';
import '../models/user_profile.dart';

enum ProfileStatus { loading, noProfile, ready }

class ProfileState {
  final ProfileStatus status;
  final UserProfile? profile;
  ProfileState({required this.status, this.profile});
}

/// Fully local, works on web too: reads/writes via LocalStore (shared_preferences).
/// The presence of a saved profile IS the "logged in" state.
class ProfileNotifier extends StateNotifier<ProfileState> {
  ProfileNotifier() : super(ProfileState(status: ProfileStatus.loading)) {
    _loadOnLaunch();
  }

  Future<void> _loadOnLaunch() async {
    final map = await LocalStore.getProfile();
    if (map == null) {
      state = ProfileState(status: ProfileStatus.noProfile);
    } else {
      state = ProfileState(status: ProfileStatus.ready, profile: UserProfile.fromDbMap(map));
    }
  }

  Future<void> createProfile({
    required String name,
    required DateTime dateOfBirth,
    required String gender,
    required double heightCm,
    required double weightKg,
    double? goalWeightKg,
    required String goal,
    required String activityLevel,
  }) async {
    final calorieGoal = GoalCalculator.calorieGoal(
      gender: gender, dateOfBirth: dateOfBirth, heightCm: heightCm, weightKg: weightKg,
      activityLevel: activityLevel, goal: goal,
    );
    final macros = GoalCalculator.macroGoals(calorieGoal, goal);

    final profile = UserProfile(
      name: name, dateOfBirth: dateOfBirth, gender: gender, heightCm: heightCm, weightKg: weightKg,
      goalWeightKg: goalWeightKg, goal: goal, activityLevel: activityLevel,
      dailyCalorieGoal: calorieGoal, proteinGoal: macros['protein']!, carbsGoal: macros['carbs']!, fatGoal: macros['fat']!,
    );

    await LocalStore.saveProfile(profile.toDbMap());
    state = ProfileState(status: ProfileStatus.ready, profile: profile);
  }

  /// Used when weight/goal/activity change - recalculates targets, same as the wizard does.
  Future<void> updateProfile(UserProfile updated) async {
    final calorieGoal = GoalCalculator.calorieGoal(
      gender: updated.gender, dateOfBirth: updated.dateOfBirth, heightCm: updated.heightCm,
      weightKg: updated.weightKg, activityLevel: updated.activityLevel, goal: updated.goal,
    );
    final macros = GoalCalculator.macroGoals(calorieGoal, updated.goal);
    final recalculated = updated.copyWith(
      dailyCalorieGoal: calorieGoal, proteinGoal: macros['protein'], carbsGoal: macros['carbs'], fatGoal: macros['fat'],
    );

    await LocalStore.saveProfile(recalculated.toDbMap());
    state = ProfileState(status: ProfileStatus.ready, profile: recalculated);
  }

  /// The only way back to Create Profile - wipes all local data.
  Future<void> resetProfile() async {
    await LocalStore.wipeAll();
    state = ProfileState(status: ProfileStatus.noProfile);
  }
}

final profileProvider = StateNotifierProvider<ProfileNotifier, ProfileState>((ref) => ProfileNotifier());
