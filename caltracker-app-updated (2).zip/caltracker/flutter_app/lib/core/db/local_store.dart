import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// Replaces the old SQLite-based LocalDb. Uses shared_preferences (JSON-encoded
/// lists under a few keys) so it works identically on Android, iOS, Windows,
/// and Web with zero extra native setup — no wasm files, no service workers.
/// Still fully local, still no backend.
class LocalStore {
  static Future<SharedPreferences> get _prefs => SharedPreferences.getInstance();

  static const _profileKey = 'profile';
  static const _logsKey = 'logs';
  static const _weightKey = 'weight_logs';
  static const _activityKey = 'activity_logs';
  static const _favoritesKey = 'favorite_foods';

  static Future<List<Map<String, dynamic>>> _getList(String key) async {
    final prefs = await _prefs;
    final raw = prefs.getString(key);
    if (raw == null) return [];
    return List<Map<String, dynamic>>.from(jsonDecode(raw));
  }

  static Future<void> _setList(String key, List<Map<String, dynamic>> list) async {
    final prefs = await _prefs;
    await prefs.setString(key, jsonEncode(list));
  }

  // ---- Profile (single record) ----
  static Future<Map<String, dynamic>?> getProfile() async {
    final prefs = await _prefs;
    final raw = prefs.getString(_profileKey);
    return raw == null ? null : Map<String, dynamic>.from(jsonDecode(raw));
  }

  static Future<void> saveProfile(Map<String, dynamic> profile) async {
    final prefs = await _prefs;
    await prefs.setString(_profileKey, jsonEncode(profile));
  }

  // ---- Meal logs ----
  static Future<List<Map<String, dynamic>>> getLogs() => _getList(_logsKey);

  static Future<void> addLogEntry(Map<String, dynamic> log) async {
    final logs = await getLogs();
    logs.add(log);
    await _setList(_logsKey, logs);
  }

  static Future<void> deleteLogEntry(String id) async {
    final logs = await getLogs();
    logs.removeWhere((l) => l['id'] == id);
    await _setList(_logsKey, logs);
  }

  // ---- Weight logs ----
  static Future<List<Map<String, dynamic>>> getWeightLogs() => _getList(_weightKey);

  static Future<void> addWeightEntry(Map<String, dynamic> entry) async {
    final list = await getWeightLogs();
    list.add(entry);
    await _setList(_weightKey, list);
  }

  // ---- Activity (steps/workouts), one record per date ----
  static Future<List<Map<String, dynamic>>> getActivityLogs() => _getList(_activityKey);

  static Future<void> upsertActivityForDate(String date, Map<String, dynamic> entry) async {
    final list = await getActivityLogs();
    final idx = list.indexWhere((a) => a['date'] == date);
    if (idx >= 0) {
      list[idx] = entry;
    } else {
      list.add(entry);
    }
    await _setList(_activityKey, list);
  }

  // ---- Favorites ----
  static Future<List<Map<String, dynamic>>> getFavorites() => _getList(_favoritesKey);

  static Future<void> addFavorite(Map<String, dynamic> favorite) async {
    final list = await getFavorites();
    list.add(favorite);
    await _setList(_favoritesKey, list);
  }

  static Future<void> deleteFavorite(String id) async {
    final list = await getFavorites();
    list.removeWhere((f) => f['id'] == id);
    await _setList(_favoritesKey, list);
  }

  // ---- Generic small key/value settings (e.g. step-counter baseline) ----
  static Future<String?> getSetting(String key) async {
    final prefs = await _prefs;
    return prefs.getString('setting_$key');
  }

  static Future<void> setSetting(String key, String value) async {
    final prefs = await _prefs;
    await prefs.setString('setting_$key', value);
  }

  // ---- Reset profile ----
  static Future<void> wipeAll() async {
    final prefs = await _prefs;
    await prefs.remove(_profileKey);
    await prefs.remove(_logsKey);
    await prefs.remove(_weightKey);
    await prefs.remove(_activityKey);
    await prefs.remove(_favoritesKey);
  }
}
