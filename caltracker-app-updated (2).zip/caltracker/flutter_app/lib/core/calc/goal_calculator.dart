/// Moved from the old Node backend into pure Dart, since the app is now fully local.
class GoalCalculator {
  static int ageFromDOB(DateTime dob) {
    final now = DateTime.now();
    int age = now.year - dob.year;
    if (now.month < dob.month || (now.month == dob.month && now.day < dob.day)) age--;
    return age;
  }

  static int calorieGoal({
    required String gender,
    required DateTime dateOfBirth,
    required double heightCm,
    required double weightKg,
    required String activityLevel,
    required String goal,
  }) {
    final age = ageFromDOB(dateOfBirth);
    double bmr = gender == 'male'
        ? 10 * weightKg + 6.25 * heightCm - 5 * age + 5
        : 10 * weightKg + 6.25 * heightCm - 5 * age - 161;

    const multipliers = {
      'sedentary': 1.2,
      'light': 1.375,
      'moderate': 1.55,
      'active': 1.725,
      'very_active': 1.9,
    };
    double tdee = bmr * (multipliers[activityLevel] ?? 1.55);

    if (goal == 'lose') tdee -= 500;
    if (goal == 'gain') tdee += 300;

    return tdee.round();
  }

  static Map<String, int> macroGoals(int dailyCalorieGoal, String goal) {
    final ratios = goal == 'lose'
        ? {'protein': 0.35, 'carbs': 0.35, 'fat': 0.30}
        : goal == 'gain'
            ? {'protein': 0.30, 'carbs': 0.45, 'fat': 0.25}
            : {'protein': 0.30, 'carbs': 0.40, 'fat': 0.30};

    return {
      'protein': ((dailyCalorieGoal * ratios['protein']!) / 4).round(),
      'carbs': ((dailyCalorieGoal * ratios['carbs']!) / 4).round(),
      'fat': ((dailyCalorieGoal * ratios['fat']!) / 9).round(),
    };
  }
}
