import 'dart:convert';
import 'package:dio/dio.dart';
import 'settings_service.dart';
import 'open_food_facts_service.dart';

class VisionScanException implements Exception {
  final String message;
  VisionScanException(this.message);
  @override
  String toString() => message;
}

/// Calls Claude's vision API directly from the device (no backend).
/// Two-step accuracy approach, same idea as before, just running client-side:
///  1. Vision AI identifies items + estimates portions (and gives a first-pass calorie guess)
///  2. Each item is cross-checked against Open Food Facts by name; if a real
///     product match is found, its numbers replace the AI's guess.
class VisionScanService {
  static final Dio _dio = Dio();

  /// [onProgress] is called with (0..1 fraction, status label) at each real
  /// step of the pipeline — not a simulated timer — so the UI can show
  /// genuine progress: image upload → AI analysis → per-item database
  /// cross-check.
  static Future<List<Map<String, dynamic>>> scanImage(
    String base64Image,
    String mediaType, {
    void Function(double progress, String label)? onProgress,
  }) async {
    final apiKey = await SettingsService.getApiKey();
    if (apiKey == null || apiKey.isEmpty) {
      throw VisionScanException('Add your Anthropic API key in Settings first to use AI food scanning.');
    }

    onProgress?.call(0.08, 'Uploading photo...');

    Response response;
    try {
      response = await _dio.post(
        'https://api.anthropic.com/v1/messages',
        options: Options(headers: {
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
          'content-type': 'application/json',
        }),
        data: {
          'model': 'claude-sonnet-4-6',
          'max_tokens': 1500,
          'messages': [
            {
              'role': 'user',
              'content': [
                {'type': 'image', 'source': {'type': 'base64', 'media_type': mediaType, 'data': base64Image}},
                {
                  'type': 'text',
                  'text': '''You are a nutrition estimation expert. Identify every distinct food/drink item in this photo.
For each item estimate: name, a visual confidence (0-100), portion size in grams (use plate size, utensils, or typical serving sizes as reference), and your best-guess calories/protein/carbs/fat for that portion.

Respond with ONLY valid JSON, no markdown fences, no other text, in this exact shape:
{"items":[{"name":"Cheeseburger","confidence":85,"estimatedGrams":210,"calories":520,"protein":27,"carbs":41,"fat":27,"description":"1 burger, homemade/restaurant style"}]}'''
                }
              ]
            }
          ]
        },
      );
    } on DioException catch (e) {
      throw VisionScanException('AI request failed: ${e.response?.data ?? e.message}');
    }

    onProgress?.call(0.55, 'Reading AI results...');

    final content = response.data['content'] as List;
    final textBlock = content.firstWhere((b) => b['type'] == 'text');
    final cleaned = (textBlock['text'] as String).replaceAll('```json', '').replaceAll('```', '').trim();
    final parsed = jsonDecode(cleaned);
    final items = List<Map<String, dynamic>>.from(parsed['items']);

    // Step 2: try to refine each item against a real product database.
    // Each iteration is a real network round-trip, so progress ticks up
    // per item rather than being simulated.
    final refined = <Map<String, dynamic>>[];
    for (var i = 0; i < items.length; i++) {
      final item = items[i];
      onProgress?.call(0.6 + (0.35 * (i / items.length)), 'Cross-checking "${item['name']}" (${i + 1}/${items.length})...');
      final match = await OpenFoodFactsService.searchByName(item['name'], (item['estimatedGrams'] as num).toDouble());
      if (match != null) {
        refined.add({
          ...item,
          'calories': match['calories'],
          'protein': match['protein'],
          'carbs': match['carbs'],
          'fat': match['fat'],
          'source': 'database_matched',
        });
      } else {
        refined.add({...item, 'source': 'ai_estimated'});
      }
    }
    onProgress?.call(1.0, 'Done');
    return refined;
  }
}
