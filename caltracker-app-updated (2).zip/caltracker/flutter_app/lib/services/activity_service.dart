import 'package:uuid/uuid.dart';
import 'package:intl/intl.dart';
import '../core/db/local_store.dart';

/// Manual steps + workout logging for the Progress tab — all local.
class ActivityService {
  static const _uuid = Uuid();

  static Future<Map<String, dynamic>?> todayEntry() async {
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final list = await LocalStore.getActivityLogs();
    final matches = list.where((a) => a['date'] == today);
    return matches.isEmpty ? null : matches.first;
  }

  static Future<void> setSteps(int steps) async {
    await _upsertToday({'steps': steps});
  }

  /// Called continuously by the live pedometer stream (see
  /// StepCounterService) so the persisted daily total always matches what
  /// the sensor is reporting in real time. Cheap no-op if unchanged.
  static Future<void> syncLiveSteps(int steps) async {
    final existing = await todayEntry();
    if ((existing?['steps'] ?? -1) == steps) return;
    await _upsertToday({'steps': steps});
  }

  static Future<void> logWorkout(int caloriesBurned) async {
    final existing = await todayEntry();
    final currentWorkouts = (existing?['workoutsCount'] ?? 0) as int;
    final currentCalories = (existing?['caloriesBurned'] ?? 0) as int;
    await _upsertToday({
      'workoutsCount': currentWorkouts + 1,
      'caloriesBurned': currentCalories + caloriesBurned,
    });
  }

  static Future<void> _upsertToday(Map<String, dynamic> fields) async {
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final existing = await todayEntry();
    final merged = {
      'id': existing?['id'] ?? const Uuid().v4(),
      'date': today,
      'steps': existing?['steps'] ?? 0,
      'workoutsCount': existing?['workoutsCount'] ?? 0,
      'caloriesBurned': existing?['caloriesBurned'] ?? 0,
      ...fields,
    };
    await LocalStore.upsertActivityForDate(today, merged);
  }
}
