import 'package:shared_preferences/shared_preferences.dart';

/// The Anthropic API key is entered once by the user in Settings and stored
/// locally. There's no backend to hold it securely server-side anymore, so
/// this is a personal-use tradeoff — fine for your own device, not for
/// shipping to the public app stores without a proxy.
class SettingsService {
  static const _apiKeyPref = 'anthropic_api_key';

  static Future<void> saveApiKey(String key) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_apiKeyPref, key);
  }

  static Future<String?> getApiKey() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_apiKeyPref);
  }
}
