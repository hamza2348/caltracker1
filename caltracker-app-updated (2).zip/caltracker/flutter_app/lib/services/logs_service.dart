import 'package:uuid/uuid.dart';
import 'package:intl/intl.dart';
import '../core/db/local_store.dart';

/// All meal logging, reading and history now goes through LocalStore
/// (shared_preferences), which works on web, mobile, and desktop alike.
class LogsService {
  static const _uuid = Uuid();

  static Future<void> addLog({
    required String name,
    required double quantityGrams,
    required int calories,
    required int protein,
    required int carbs,
    required int fat,
    required String mealType,
    String? date,
  }) async {
    await LocalStore.addLogEntry({
      'id': _uuid.v4(),
      'name': name,
      'quantityGrams': quantityGrams,
      'calories': calories,
      'protein': protein,
      'carbs': carbs,
      'fat': fat,
      'mealType': mealType,
      'date': date ?? DateFormat('yyyy-MM-dd').format(DateTime.now()),
      'loggedAt': DateTime.now().toIso8601String(),
    });
  }

  static Future<List<Map<String, dynamic>>> logsForDate(String date) async {
    final logs = await LocalStore.getLogs();
    final filtered = logs.where((l) => l['date'] == date).toList();
    filtered.sort((a, b) => (b['loggedAt'] as String).compareTo(a['loggedAt'] as String));
    return filtered;
  }

  static Future<Map<String, int>> totalsForDate(String date) async {
    final logs = await logsForDate(date);
    return logs.fold<Map<String, int>>(
      {'calories': 0, 'protein': 0, 'carbs': 0, 'fat': 0},
      (acc, log) => {
        'calories': acc['calories']! + (log['calories'] as int),
        'protein': acc['protein']! + (log['protein'] as int),
        'carbs': acc['carbs']! + (log['carbs'] as int),
        'fat': acc['fat']! + (log['fat'] as int),
      },
    );
  }

  static Future<void> deleteLog(String id) async {
    await LocalStore.deleteLogEntry(id);
  }

  /// Grouped daily summaries for the History screen, most recent first.
  static Future<List<Map<String, dynamic>>> history({int days = 61}) async {
    final since = DateTime.now().subtract(Duration(days: days));
    final sinceStr = DateFormat('yyyy-MM-dd').format(since);
    final logs = await LocalStore.getLogs();
    final rows = logs.where((l) => (l['date'] as String).compareTo(sinceStr) >= 0);

    final byDate = <String, Map<String, dynamic>>{};
    for (final row in rows) {
      final date = row['date'] as String;
      byDate.putIfAbsent(date, () => {'date': date, 'mealsCount': 0, 'calories': 0, 'protein': 0, 'carbs': 0, 'fat': 0});
      byDate[date]!['mealsCount'] += 1;
      byDate[date]!['calories'] += row['calories'] as int;
      byDate[date]!['protein'] += row['protein'] as int;
      byDate[date]!['carbs'] += row['carbs'] as int;
      byDate[date]!['fat'] += row['fat'] as int;
    }
    final list = byDate.values.toList()..sort((a, b) => (b['date'] as String).compareTo(a['date'] as String));
    return list;
  }
}
