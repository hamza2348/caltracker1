import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;

/// A small bundled dataset of common foods (~40 items) so manual entry has
/// instant search results with zero internet — this is the fully-offline
/// logging path. Loaded once and cached in memory.
class LocalFoodDatabaseService {
  static List<Map<String, dynamic>>? _cache;

  static Future<List<Map<String, dynamic>>> _load() async {
    if (_cache != null) return _cache!;
    final jsonStr = await rootBundle.loadString('assets/common_foods.json');
    _cache = List<Map<String, dynamic>>.from(jsonDecode(jsonStr));
    return _cache!;
  }

  static Future<List<Map<String, dynamic>>> search(String query) async {
    final foods = await _load();
    if (query.trim().isEmpty) return foods.take(10).toList();
    final q = query.toLowerCase();
    return foods.where((f) => (f['name'] as String).toLowerCase().contains(q)).toList();
  }
}
