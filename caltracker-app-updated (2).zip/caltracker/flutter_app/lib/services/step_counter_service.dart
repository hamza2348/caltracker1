import 'dart:async';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:pedometer/pedometer.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:intl/intl.dart';
import '../core/db/local_store.dart';

enum StepTrackingState {
  /// Haven't checked permission/support yet.
  unknown,
  /// Live tracking is running — either the OS step sensor or the
  /// accelerometer-based fallback. Zero steps just means you haven't
  /// moved yet, not that anything's wrong.
  live,
  /// No motion sensor of any kind could be found on this device/browser.
  unsupported,
  /// Sensor exists but permission was denied.
  permissionDenied,
}

/// Fully automatic, no manual entry anywhere.
///
/// Primary source: the phone's real OS step-counter sensor (Android
/// TYPE_STEP_COUNTER / iOS CMPedometer, via `pedometer`). That sensor
/// reports a value that counts up forever from boot, so we record a
/// "baseline" the first time we see it each day and today's steps =
/// rawValue - baseline.
///
/// Fallback (used automatically whenever the OS step sensor isn't
/// available — web, desktop, or a phone without that sensor): a live
/// accelerometer-based step detector. It watches the device's motion
/// sensor directly and counts a step every time it sees the acceleration
/// pattern of a footstep (a peak above a threshold, with a short
/// refractory window so one footstep isn't counted twice). This is what
/// makes steps start counting the instant you start walking or running —
/// there's no OS pedometer needed for it to work, just a working
/// accelerometer. A desktop/laptop with no accelerometer physically has
/// no signal to read, so on those it stays at 0 until you're on a device
/// that actually has motion hardware — that's a hardware limit, not
/// something any app can work around.
class StepCounterService {
  StepCounterService._();
  static final StepCounterService instance = StepCounterService._();

  final _stepsController = StreamController<int>.broadcast();
  final _statusController = StreamController<String>.broadcast();
  final _stateController = StreamController<StepTrackingState>.broadcast();

  Stream<int> get steps => _stepsController.stream;
  Stream<String> get walkingStatus => _statusController.stream;
  Stream<StepTrackingState> get state => _stateController.stream;

  StreamSubscription<StepCount>? _stepSub;
  StreamSubscription<PedestrianStatus>? _statusSub;
  StreamSubscription<UserAccelerometerEvent>? _accelSub;
  Timer? _walkingTimeoutTimer;

  int? _baseline;
  String _day = '';
  int _fallbackSteps = 0;
  bool _starting = false;
  bool _usingFallback = false;

  DateTime? _lastStepAt;
  bool _wasAboveThreshold = false;

  // Tuned for a normal walking/running cadence: a step's acceleration
  // spike needs to clear this, and steps can't register faster than the
  // refractory window (prevents one footstep triggering twice).
  static const _stepThreshold = 1.35; // m/s^2 above gravity-compensated rest
  static const _refractoryMs = 280;

  static const _baselineKey = 'step_baseline_value';
  static const _baselineDateKey = 'step_baseline_date';
  static const _fallbackKey = 'step_fallback_value';
  static const _fallbackDateKey = 'step_fallback_date';

  String get _today => DateFormat('yyyy-MM-dd').format(DateTime.now());

  bool get _pedometerPlatform {
    if (kIsWeb) return false;
    return defaultTargetPlatform == TargetPlatform.android || defaultTargetPlatform == TargetPlatform.iOS;
  }

  Future<void> start() async {
    if (_starting || _stepSub != null || _accelSub != null) return;
    _starting = true;
    _day = _today;

    final granted = await _ensurePermission();
    if (!granted) {
      _stateController.add(StepTrackingState.permissionDenied);
      _starting = false;
      return;
    }

    if (_pedometerPlatform) {
      final ok = await _startPedometer();
      if (ok) {
        _starting = false;
        return;
      }
    }
    await _startAccelerometerFallback();
    _starting = false;
  }

  Future<bool> _ensurePermission() async {
    // Only Android/iOS gate this behind a runtime permission; web/desktop
    // accelerometer access doesn't go through permission_handler.
    if (!_pedometerPlatform) return true;
    final status = await Permission.activityRecognition.status;
    if (status.isGranted) return true;
    final result = await Permission.activityRecognition.request();
    return result.isGranted;
  }

  Future<bool> _startPedometer() async {
    final completer = Completer<bool>();
    var resolved = false;

    await _loadBaseline();

    _statusSub = Pedometer.pedestrianStatusStream.listen(
      (status) => _statusController.add(status.status),
      onError: (_) {},
      cancelOnError: false,
    );

    _stepSub = Pedometer.stepCountStream.listen(
      (event) {
        if (!resolved) {
          resolved = true;
          _usingFallback = false;
          _stateController.add(StepTrackingState.live);
          completer.complete(true);
        }
        _onPedometerEvent(event);
      },
      onError: (_) {
        if (!resolved) {
          resolved = true;
          completer.complete(false);
        }
      },
      cancelOnError: false,
    );

    // Give the real sensor a moment to report before deciding it's absent.
    Future.delayed(const Duration(seconds: 3), () {
      if (!resolved) {
        resolved = true;
        _stepSub?.cancel();
        _statusSub?.cancel();
        _stepSub = null;
        _statusSub = null;
        completer.complete(false);
      }
    });

    return completer.future;
  }

  Future<void> _loadBaseline() async {
    final storedDate = await LocalStore.getSetting(_baselineDateKey);
    final storedBaseline = await LocalStore.getSetting(_baselineKey);
    if (storedDate == _day && storedBaseline != null) {
      _baseline = int.tryParse(storedBaseline);
    } else {
      _baseline = null;
    }
  }

  void _onPedometerEvent(StepCount event) async {
    final today = _today;
    if (today != _day) {
      _day = today;
      _baseline = null;
    }
    if (_baseline == null || event.steps < _baseline!) {
      _baseline = event.steps;
      await LocalStore.setSetting(_baselineKey, event.steps.toString());
      await LocalStore.setSetting(_baselineDateKey, today);
    }
    _stepsController.add(event.steps - _baseline!);
  }

  Future<void> _startAccelerometerFallback() async {
    _usingFallback = true;
    await _loadFallbackCount();

    try {
      _accelSub = userAccelerometerEventStream(
        samplingPeriod: const Duration(milliseconds: 60),
      ).listen(
        _onAccelerometerEvent,
        onError: (_) => _stateController.add(StepTrackingState.unsupported),
        cancelOnError: false,
      );
      _stateController.add(StepTrackingState.live);
    } catch (_) {
      _stateController.add(StepTrackingState.unsupported);
    }
  }

  Future<void> _loadFallbackCount() async {
    final storedDate = await LocalStore.getSetting(_fallbackDateKey);
    final stored = await LocalStore.getSetting(_fallbackKey);
    if (storedDate == _day && stored != null) {
      _fallbackSteps = int.tryParse(stored) ?? 0;
    } else {
      _fallbackSteps = 0;
    }
    _stepsController.add(_fallbackSteps);
  }

  void _onAccelerometerEvent(UserAccelerometerEvent event) {
    final today = _today;
    if (today != _day) {
      _day = today;
      _fallbackSteps = 0;
    }

    final magnitude = sqrt(event.x * event.x + event.y * event.y + event.z * event.z);
    final isAboveThreshold = magnitude > _stepThreshold;
    final now = DateTime.now();

    // Rising edge crossing the threshold = the sharp part of a footstep.
    if (isAboveThreshold && !_wasAboveThreshold) {
      final longEnoughSinceLastStep =
          _lastStepAt == null || now.difference(_lastStepAt!).inMilliseconds > _refractoryMs;
      if (longEnoughSinceLastStep) {
        _lastStepAt = now;
        _fallbackSteps++;
        _stepsController.add(_fallbackSteps);
        LocalStore.setSetting(_fallbackKey, _fallbackSteps.toString());
        LocalStore.setSetting(_fallbackDateKey, today);

        _statusController.add('walking');
        _walkingTimeoutTimer?.cancel();
        _walkingTimeoutTimer = Timer(const Duration(seconds: 2), () {
          _statusController.add('stopped');
        });
      }
    }

    _wasAboveThreshold = isAboveThreshold;
  }

  bool get isUsingFallback => _usingFallback;

  Future<void> requestPermissionAgain() async {
    _stepSub?.cancel();
    _statusSub?.cancel();
    _accelSub?.cancel();
    _stepSub = null;
    _statusSub = null;
    _accelSub = null;
    await start();
  }

  Future<void> openSystemSettings() => openAppSettings();

  void dispose() {
    _stepSub?.cancel();
    _statusSub?.cancel();
    _accelSub?.cancel();
    _walkingTimeoutTimer?.cancel();
  }
}
