import 'package:uuid/uuid.dart';
import 'package:intl/intl.dart';
import '../core/db/local_store.dart';

class WeightService {
  static const _uuid = Uuid();

  static Future<void> addEntry(double weightKg, {String? date}) async {
    await LocalStore.addWeightEntry({
      'id': _uuid.v4(),
      'weightKg': weightKg,
      'date': date ?? DateFormat('yyyy-MM-dd').format(DateTime.now()),
    });
  }

  static Future<List<Map<String, dynamic>>> history() async {
    final list = await LocalStore.getWeightLogs();
    list.sort((a, b) => (a['date'] as String).compareTo(b['date'] as String));
    return list;
  }
}
