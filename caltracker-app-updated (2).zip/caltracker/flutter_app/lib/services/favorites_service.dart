import 'package:uuid/uuid.dart';
import '../core/db/local_store.dart';

/// Saved foods for one-tap re-logging - entirely local, works offline (and on web).
class FavoritesService {
  static const _uuid = Uuid();

  static Future<void> save({
    required String name,
    required double caloriesPer100g,
    required double proteinPer100g,
    required double carbsPer100g,
    required double fatPer100g,
  }) async {
    await LocalStore.addFavorite({
      'id': _uuid.v4(),
      'name': name,
      'caloriesPer100g': caloriesPer100g,
      'proteinPer100g': proteinPer100g,
      'carbsPer100g': carbsPer100g,
      'fatPer100g': fatPer100g,
      'createdAt': DateTime.now().toIso8601String(),
    });
  }

  static Future<List<Map<String, dynamic>>> all() async {
    final list = await LocalStore.getFavorites();
    list.sort((a, b) => (a['name'] as String).compareTo(b['name'] as String));
    return list;
  }

  static Future<void> delete(String id) async {
    await LocalStore.deleteFavorite(id);
  }
}
