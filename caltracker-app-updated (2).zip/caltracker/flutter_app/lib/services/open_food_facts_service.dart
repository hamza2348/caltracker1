import 'package:dio/dio.dart';

/// Open Food Facts is a free, public, crowdsourced food database — no API
/// key needed. Used both for barcode lookups and to sanity-check AI scan
/// results against real product data.
class OpenFoodFactsService {
  static final Dio _dio = Dio();

  /// Barcode -> product info. Returns null if not found.
  static Future<Map<String, dynamic>?> lookupBarcode(String barcode) async {
    try {
      final res = await _dio.get('https://world.openfoodfacts.org/api/v2/product/$barcode.json');
      if (res.data['status'] != 1) return null;
      final product = res.data['product'];
      final nutriments = product['nutriments'] ?? {};

      return {
        'name': product['product_name'] ?? 'Unknown product',
        'brand': product['brands'],
        'caloriesPer100g': (nutriments['energy-kcal_100g'] as num?)?.toDouble() ?? 0,
        'proteinPer100g': (nutriments['proteins_100g'] as num?)?.toDouble() ?? 0,
        'carbsPer100g': (nutriments['carbohydrates_100g'] as num?)?.toDouble() ?? 0,
        'fatPer100g': (nutriments['fat_100g'] as num?)?.toDouble() ?? 0,
        'servingSize': product['serving_quantity'],
      };
    } catch (_) {
      return null;
    }
  }

  /// Text search -> best match, scaled to the given portion in grams.
  /// Used to refine AI scan results with real product data where possible.
  static Future<Map<String, dynamic>?> searchByName(String name, double grams) async {
    try {
      final res = await _dio.get(
        'https://world.openfoodfacts.org/cgi/search.pl',
        queryParameters: {'search_terms': name, 'search_simple': 1, 'action': 'process', 'json': 1, 'page_size': 1},
      );
      final products = res.data['products'] as List?;
      if (products == null || products.isEmpty) return null;

      final nutriments = products.first['nutriments'] ?? {};
      final caloriesPer100g = (nutriments['energy-kcal_100g'] as num?)?.toDouble();
      if (caloriesPer100g == null) return null;

      final factor = grams / 100;
      return {
        'calories': (caloriesPer100g * factor).round(),
        'protein': (((nutriments['proteins_100g'] as num?) ?? 0) * factor).round(),
        'carbs': (((nutriments['carbohydrates_100g'] as num?) ?? 0) * factor).round(),
        'fat': (((nutriments['fat_100g'] as num?) ?? 0) * factor).round(),
      };
    } catch (_) {
      return null;
    }
  }
}
