// Basic smoke test: confirms the app boots without crashing and shows
// the splash screen while it checks for a saved profile.
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:caltracker/main.dart';

void main() {
  testWidgets('App boots and shows splash while checking for a profile', (WidgetTester tester) async {
    await tester.pumpWidget(const ProviderScope(child: CalTrackerApp()));
    // Before the local DB check resolves, splash content should be visible.
    await tester.pump();
    expect(find.text('CalTracker AI'), findsOneWidget);
  });
}
