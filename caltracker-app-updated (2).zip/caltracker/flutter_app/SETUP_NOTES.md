# Setup notes — real-time step counting

The app now counts steps live using your phone's built-in motion sensor
(via the `pedometer` package) instead of manual entry. This project only
ships Dart source + pubspec.yaml (no `android/` or `ios/` folders were in
your zip), so there's one manual step left once you generate/open those
platform folders:

## Android
Add this permission to `android/app/src/main/AndroidManifest.xml`
(inside the `<manifest>` tag, alongside any other `<uses-permission>` lines):

```xml
<uses-permission android:name="android.permission.ACTIVITY_RECOGNITION"/>
```

Android 10+ (API 29+) requires this for the step-counter sensor. If your
`minSdkVersion` is below 21, bump it to at least 21 in
`android/app/build.gradle` — the pedometer package requires it.

## iOS
Add this key to `ios/Runner/Info.plist`:

```xml
<key>NSMotionUsageDescription</key>
<string>CalTracker uses motion data to count your steps in real time.</string>
```

## What happens without this
The app still works fine — if the permission is missing or denied, the
Progress screen shows a clear "Enable" prompt and falls back to manual
step entry (tap "adjust"). Nothing crashes.

## Platforms without a step sensor (web, desktop)
Live tracking automatically falls back to manual entry there too — the
`pedometer` package only supports Android and iOS.
